import type { CapacitorConfig } from "@capacitor/cli";
const config: CapacitorConfig = {
  appId: "local.personal.liner.alpha2",
  appName: "Liner",
  webDir: "dist-mobile",
  server: { androidScheme: "https" },
  ios: { backgroundColor: "#101114", contentInset: "never" },
  android: { backgroundColor: "#101114", allowMixedContent: false },
  plugins: { CapacitorHttp: { enabled: true } },
};
export default config;
