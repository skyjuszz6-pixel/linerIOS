#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "IPA compilation requires macOS and Xcode, not the simulator SDK on Linux." >&2
  exit 1
fi
xcodebuild -version
mkdir -p artifacts
xcodebuild -project ios/App/App.xcodeproj -scheme App \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath .ios-derived-data \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY='' \
  build 2>&1 | tee artifacts/xcodebuild.log
app='.ios-derived-data/Build/Products/Release-iphoneos/App.app'
test -d "$app"
test -f "$app/Info.plist"
executable=$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$app/Info.plist")
test -f "$app/$executable"
xcrun lipo -verify_arch arm64 "$app/$executable"
package_dir=$(mktemp -d "${TMPDIR:-/tmp}/liner-ipa.XXXXXX")
trap 'rm -rf "$package_dir"' EXIT
mkdir -p "$package_dir/Payload"
ditto "$app" "$package_dir/Payload/App.app"
output="$PWD/artifacts/Liner-iOS-Alpha1-unsigned.ipa"
(cd "$package_dir" && /usr/bin/zip -qry "$output" Payload)
/usr/bin/unzip -t "$output"
shasum -a 256 "$output" > "$output.sha256"
echo "Built unsigned device IPA; signing is still required for installation."
