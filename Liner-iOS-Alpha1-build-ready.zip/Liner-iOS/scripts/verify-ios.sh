#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "Native iOS verification requires macOS with Xcode 26 or newer." >&2
  exit 1
fi
xcodebuild -version
npm ci --ignore-scripts --no-audit --no-fund
npm run mobile:test
npx tsc --noEmit
npm run ios:sync
xcodebuild -project ios/App/App.xcodeproj -scheme App \
  -configuration Debug -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath .ios-derived-data CODE_SIGNING_ALLOWED=NO build
