import Foundation
import UIKit
import AVFoundation
import UniformTypeIdentifiers
import Capacitor

@objc(OfflineAudioPlugin)
public final class OfflineAudioPlugin: CAPPlugin, CAPBridgedPlugin, UIDocumentPickerDelegate {
    public let identifier = "OfflineAudioPlugin"
    public let jsName = "OfflineAudio"
    public let pluginMethods = ["list", "importAudio", "remove"].map { CAPPluginMethod(name: $0, returnType: CAPPluginReturnPromise) }
    private let io = DispatchQueue(label: "Liner.offline", qos: .utility)
    private var pickerCall: CAPPluginCall?
    static var folderURL: URL {
        FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0].appendingPathComponent("LinerOffline", isDirectory: true)
    }
    private func read() throws -> [JSObject] {
        try FileManager.default.createDirectory(at: Self.folderURL, withIntermediateDirectories: true)
        let url = Self.folderURL.appendingPathComponent("library.json")
        guard FileManager.default.fileExists(atPath: url.path) else { return [] }
        guard let rows = try JSONSerialization.jsonObject(with: Data(contentsOf: url)) as? [JSObject] else {
            throw NSError(domain: "Liner", code: 1, userInfo: [NSLocalizedDescriptionKey: "Nieprawidłowy indeks biblioteki"])
        }
        return rows
    }
    private func write(_ rows: [JSObject]) throws {
        let data = try JSONSerialization.data(withJSONObject: rows)
        try data.write(to: Self.folderURL.appendingPathComponent("library.json"), options: .atomic)
    }
    private func response(_ rows: [JSObject], failed: Int = 0) -> JSObject {
        var total = 0
        let tracks = rows.compactMap { row -> JSObject? in
            guard let filename = row["filename"] as? String, filename == (filename as NSString).lastPathComponent else { return nil }
            var track = row
            track.removeValue(forKey: "filename")
            track["localUrl"] = Self.folderURL.appendingPathComponent(filename).absoluteString
            total += (row["offlineBytes"] as? NSNumber)?.intValue ?? 0
            return track
        }
        return ["tracks": tracks, "bytes": total, "failed": failed]
    }
    @objc func list(_ call: CAPPluginCall) {
        io.async {
            do { call.resolve(self.response(try self.read())) }
            catch { call.reject(error.localizedDescription) }
        }
    }
    @objc func importAudio(_ call: CAPPluginCall) {
        DispatchQueue.main.async {
            guard self.pickerCall == nil else { call.reject("Import jest już otwarty"); return }
            guard let controller = self.bridge?.viewController else { call.reject("Brak widoku aplikacji"); return }
            self.pickerCall = call
            let picker = UIDocumentPickerViewController(forOpeningContentTypes: [.audio], asCopy: false)
            picker.allowsMultipleSelection = true
            picker.delegate = self
            controller.present(picker, animated: true)
        }
    }
    public func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        pickerCall?.resolve()
        pickerCall = nil
    }
    public func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let call = pickerCall else { return }
        pickerCall = nil
        io.async {
            do {
                var rows = try self.read()
                var failed = max(0, urls.count - 100)
                for source in urls.prefix(100) {
                    let accessible = source.startAccessingSecurityScopedResource()
                    defer { if accessible { source.stopAccessingSecurityScopedResource() } }
                    let filename = UUID().uuidString + "." + source.pathExtension.lowercased()
                    let target = Self.folderURL.appendingPathComponent(filename)
                    do {
                        var coordinationError: NSError?
                        var copyError: Error?
                        NSFileCoordinator().coordinate(readingItemAt: source, options: [], error: &coordinationError) { coordinated in
                            do {
                                let size = try coordinated.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                                guard size > 0 && size <= 512 * 1024 * 1024 else {
                                    throw NSError(domain: "Liner", code: 2, userInfo: [NSLocalizedDescriptionKey: "Plik jest pusty lub przekracza 512 MiB"])
                                }
                                try FileManager.default.copyItem(at: coordinated, to: target)
                            } catch { copyError = error }
                        }
                        if let coordinationError { throw coordinationError }
                        if let copyError { throw copyError }
                        let asset = AVURLAsset(url: target)
                        guard asset.isPlayable && !asset.tracks(withMediaType: .audio).isEmpty else {
                            throw NSError(domain: "Liner", code: 3, userInfo: [NSLocalizedDescriptionKey: "Nieobsługiwane audio"])
                        }
                        let metadata = asset.commonMetadata
                        let title = AVMetadataItem.metadataItems(from: metadata, filteredByIdentifier: .commonIdentifierTitle).first?.stringValue
                        let artist = AVMetadataItem.metadataItems(from: metadata, filteredByIdentifier: .commonIdentifierArtist).first?.stringValue
                        let seconds = asset.duration.seconds
                        let size = try target.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                        let row: JSObject = ["id": "local:" + filename, "filename": filename,
                            "title": title ?? source.deletingPathExtension().lastPathComponent,
                            "artists": artist ?? "Nieznany wykonawca", "durationMs": seconds.isFinite ? max(0, seconds * 1000) : 0,
                            "coverUrl": "", "playCount": 0, "offlineBytes": size]
                        let updated = rows + [row]
                        try self.write(updated)
                        rows = updated
                    } catch { try? FileManager.default.removeItem(at: target); failed += 1 }
                }
                call.resolve(self.response(rows, failed: failed))
            } catch { call.reject(error.localizedDescription) }
        }
    }
    @objc func remove(_ call: CAPPluginCall) {
        guard let id = call.getString("id") else { call.reject("Brak ID utworu"); return }
        io.async {
            do {
                let rows = try self.read()
                guard let row = rows.first(where: { $0["id"] as? String == id }),
                      let filename = row["filename"] as? String,
                      filename == (filename as NSString).lastPathComponent else { call.reject("Nieznany utwór"); return }
                let target = Self.folderURL.appendingPathComponent(filename)
                let trash = target.appendingPathExtension("deleting")
                let exists = FileManager.default.fileExists(atPath: target.path)
                if exists { try FileManager.default.moveItem(at: target, to: trash) }
                let next = rows.filter { $0["id"] as? String != id }
                do { try self.write(next) }
                catch {
                    if exists { try? FileManager.default.moveItem(at: trash, to: target) }
                    throw error
                }
                if exists { try? FileManager.default.removeItem(at: trash) }
                call.resolve(self.response(next))
            } catch { call.reject(error.localizedDescription) }
        }
    }
}
