import Foundation
import AVFoundation
import MediaPlayer
import UIKit
import Capacitor

// All player mutations and bridge replies run on the main queue. Queue revisions
// and generation tokens reject late source, artwork, seek and KVO completions.
@objc(LinerAudioPlugin)
public final class LinerAudioPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "LinerAudioPlugin"
    public let jsName = "LinerAudio"
    public let pluginMethods = ["getState", "setQueue", "select", "supplySource", "failSource",
        "next", "previous", "play", "pause", "stop", "seek", "configure", "cacheAudio"]
        .map { CAPPluginMethod(name: $0, returnType: CAPPluginReturnPromise) }

    private struct Entry {
        let key: String
        let title: String
        let artists: String
        let cover: String
        var url: URL?
        var expires: Double = 0
    }
    private let player = AVPlayer()
    private var entries: [Entry] = []
    private var selected = -1
    private var revision = ""
    private var generation = 0
    private var wantsPlay = false
    private var resumeAfterInterruption = false
    private var interrupted = false
    private var repeatMode = "off"
    private var speed: Float = 1
    private var pendingPosition: Double = 0
    private var errorText: String?
    private var hasEnded = false
    private var itemObservation: NSKeyValueObservation?
    private var controlObservation: NSKeyValueObservation?
    private var timeObserver: Any?
    private var notifications: [NSObjectProtocol] = []
    private var remoteTargets: [(MPRemoteCommand, Any)] = []
    private var artworkTask: URLSessionDataTask?
    private var artwork: MPMediaItemArtwork?
    private var sourceTimeout: DispatchWorkItem?
    private var current: Entry? { entries.indices.contains(selected) ? entries[selected] : nil }

    public override func load() {
        DispatchQueue.main.async { [weak self] in self?.setup() }
    }
    private func setup() {
        try? FileManager.default.removeItem(at: cacheFolder)
        player.automaticallyWaitsToMinimizeStalling = true
        player.allowsExternalPlayback = true
        controlObservation = player.observe(\.timeControlStatus, options: [.new]) { [weak self] _, _ in
            DispatchQueue.main.async { self?.emit() }
        }
        timeObserver = player.addPeriodicTimeObserver(forInterval: CMTime(seconds: 0.5, preferredTimescale: 600), queue: .main) { [weak self] _ in self?.emit() }
        let center = NotificationCenter.default
        notifications.append(center.addObserver(forName: .AVPlayerItemDidPlayToEndTime, object: nil, queue: .main) { [weak self] note in
            guard let self, let item = note.object as? AVPlayerItem, item === self.player.currentItem else { return }
            self.finishTrack()
        })
        notifications.append(center.addObserver(forName: .AVPlayerItemFailedToPlayToEndTime, object: nil, queue: .main) { [weak self] note in
            guard let self, let item = note.object as? AVPlayerItem, item === self.player.currentItem else { return }
            self.fail("Odtwarzanie przerwane. Sprawdź połączenie i spróbuj ponownie.")
        })
        notifications.append(center.addObserver(forName: AVAudioSession.interruptionNotification, object: nil, queue: .main) { [weak self] note in
            guard let self, let raw = note.userInfo?[AVAudioSessionInterruptionTypeKey] as? UInt,
                  let type = AVAudioSession.InterruptionType(rawValue: raw) else { return }
            if type == .began {
                self.interrupted = true
                self.resumeAfterInterruption = self.wantsPlay
                self.wantsPlay = false
                self.player.pause()
                self.emit()
            } else {
                self.interrupted = false
                let rawOptions = note.userInfo?[AVAudioSessionInterruptionOptionKey] as? UInt ?? 0
                if self.resumeAfterInterruption && AVAudioSession.InterruptionOptions(rawValue: rawOptions).contains(.shouldResume) { self.start() }
                self.resumeAfterInterruption = false
            }
        })
        notifications.append(center.addObserver(forName: AVAudioSession.routeChangeNotification, object: nil, queue: .main) { [weak self] note in
            let raw = note.userInfo?[AVAudioSessionRouteChangeReasonKey] as? UInt ?? 0
            if AVAudioSession.RouteChangeReason(rawValue: raw) == .oldDeviceUnavailable { self?.pausePlayback() }
        })
        notifications.append(center.addObserver(forName: AVAudioSession.mediaServicesWereResetNotification, object: nil, queue: .main) { [weak self] _ in
            self?.fail("Usługi audio zostały zresetowane. Uruchom aplikację ponownie.")
        })
        let remote = MPRemoteCommandCenter.shared()
        bind(remote.playCommand) { $0.start() }
        bind(remote.pauseCommand) { $0.pausePlayback() }
        bind(remote.togglePlayPauseCommand) { $0.wantsPlay ? $0.pausePlayback() : $0.start() }
        bind(remote.nextTrackCommand) { $0.advance(1) }
        bind(remote.previousTrackCommand) { $0.advance(-1) }
        remote.changePlaybackPositionCommand.isEnabled = true
        let token = remote.changePlaybackPositionCommand.addTarget { [weak self] event in
            guard let self, let event = event as? MPChangePlaybackPositionCommandEvent else { return .commandFailed }
            DispatchQueue.main.async { self.seekTo(event.positionTime * 1000) }
            return .success
        }
        remoteTargets.append((remote.changePlaybackPositionCommand, token))
    }
    private func bind(_ command: MPRemoteCommand, action: @escaping (LinerAudioPlugin) -> Void) {
        command.isEnabled = true
        let token = command.addTarget { [weak self] _ in
            guard let self else { return .commandFailed }
            DispatchQueue.main.async { action(self) }
            return .success
        }
        remoteTargets.append((command, token))
    }
    private func onMain(_ call: CAPPluginCall, _ action: @escaping () throws -> Void) {
        DispatchQueue.main.async {
            do { try action() } catch { call.reject(error.localizedDescription) }
        }
    }
    private func milliseconds(_ time: CMTime) -> Double {
        let seconds = time.seconds
        return seconds.isFinite ? max(0, seconds * 1000) : 0
    }
    private func snapshot() -> JSObject {
        let status: String
        if errorText != nil { status = "error" }
        else if !wantsPlay { status = "paused" }
        else if player.timeControlStatus == .playing { status = "playing" }
        else { status = "loading" }
        var state: JSObject = ["key": current?.key ?? "", "revision": revision, "status": status,
            "positionMs": player.currentItem == nil ? pendingPosition : milliseconds(player.currentTime()),
            "durationMs": player.currentItem.map { milliseconds($0.duration) } ?? 0, "ended": hasEnded]
        if let errorText { state["error"] = errorText }
        return state
    }
    private func emit(_ event: String = "state", reason: Int? = nil) {
        var state = snapshot()
        if let reason { state["reason"] = reason }
        notifyListeners(event, data: state)
        updateNowPlaying()
    }
    private func fail(_ text: String) {
        sourceTimeout?.cancel()
        errorText = text
        wantsPlay = false
        player.pause()
        emit()
    }
    private func activate() throws {
        let session = AVAudioSession.sharedInstance()
        try session.setCategory(.playback, mode: .default)
        try session.setActive(true)
    }
    private func pausePlayback() {
        wantsPlay = false
        resumeAfterInterruption = false
        player.pause()
        emit()
    }
    private func start() {
        guard current != nil else { return }
        guard !interrupted else { return }
        do { try activate() } catch { fail("Nie można uruchomić sesji audio: \(error.localizedDescription)"); return }
        wantsPlay = true
        if hasEnded { hasEnded = false; seekTo(0) }
        if errorText != nil || player.currentItem == nil { errorText = nil; loadSelected(position: pendingPosition) }
        else { player.playImmediately(atRate: speed); emit() }
    }
    private func validURL(_ value: String) -> URL? {
        guard let url = URL(string: value) else { return nil }
        if url.scheme == "https" { return url }
        guard url.isFileURL else { return nil }
        // iOS may relocate the app container after installation; only resolve
        // filenames inside this app's offline/cache directories.
        for directory in [OfflineAudioPlugin.folderURL, cacheFolder] {
            let candidate = directory.appendingPathComponent(url.lastPathComponent)
            if FileManager.default.fileExists(atPath: candidate.path) { return candidate }
        }
        return nil
    }
    private var cacheFolder: URL {
        FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("LinerAudio", isDirectory: true)
    }
    private func loadSelected(position: Double = 0) {
        generation += 1
        let token = generation
        pendingPosition = max(0, position)
        sourceTimeout?.cancel()
        itemObservation = nil
        player.pause()
        player.replaceCurrentItem(with: nil)
        errorText = nil
        hasEnded = false
        guard let entry = current else { emit(); return }
        if entry.expires > 0 && entry.expires <= Date().timeIntervalSince1970 * 1000 + 5000 { entries[selected].url = nil }
        guard let url = entries[selected].url else {
            notifyListeners("sourceNeeded", data: ["key": entry.key, "revision": revision])
            let timeout = DispatchWorkItem { [weak self] in
                guard let self, self.generation == token, self.player.currentItem == nil else { return }
                self.fail("Źródło nie jest gotowe. Otwórz Liner i ponów odtwarzanie.")
            }
            sourceTimeout = timeout
            DispatchQueue.main.asyncAfter(deadline: .now() + 45, execute: timeout)
            emit()
            return
        }
        let item = AVPlayerItem(url: url)
        item.audioTimePitchAlgorithm = .timeDomain
        item.preferredForwardBufferDuration = 10
        itemObservation = item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            DispatchQueue.main.async {
                guard let self, self.generation == token, item === self.player.currentItem else { return }
                if item.status == .failed {
                    self.fail("Nie można odtworzyć źródła: \(item.error?.localizedDescription ?? "nieobsługiwany format")")
                } else if item.status == .readyToPlay {
                    self.seekTo(self.pendingPosition)
                }
            }
        }
        player.replaceCurrentItem(with: item)
        emit()
    }
    private func seekTo(_ position: Double) {
        guard position.isFinite else { return }
        let duration = player.currentItem.map { milliseconds($0.duration) } ?? 0
        pendingPosition = max(0, duration > 0 ? min(position, duration) : position)
        guard player.currentItem?.status == .readyToPlay else { emit(); return }
        hasEnded = false
        let token = generation
        player.seek(to: CMTime(seconds: pendingPosition / 1000, preferredTimescale: 600), toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] finished in
            DispatchQueue.main.async {
                guard let self, finished, self.generation == token else { return }
                if self.wantsPlay && !self.interrupted { self.player.playImmediately(atRate: self.speed) }
                self.emit()
            }
        }
    }
    private func choose(_ index: Int, position: Double = 0, reason: Int? = nil) {
        guard entries.indices.contains(index) else { return }
        selected = index
        wantsPlay = true
        do { try activate() } catch { fail(error.localizedDescription); return }
        loadArtwork()
        loadSelected(position: position)
        if let reason { emit("transition", reason: reason) }
    }
    private func advance(_ direction: Int) {
        guard current != nil else { return }
        if direction < 0 && milliseconds(player.currentTime()) > 3000 { seekTo(0); return }
        var index = selected + direction
        if !entries.indices.contains(index) {
            if repeatMode == "all" { index = direction > 0 ? 0 : entries.count - 1 }
            else { if direction < 0 { seekTo(0) }; return }
        }
        choose(index, reason: 2)
    }
    private func finishTrack() {
        if repeatMode == "one" { seekTo(0); emit("transition", reason: 0) }
        else if selected + 1 < entries.count { choose(selected + 1, reason: 1) }
        else if repeatMode == "all" { choose(0, reason: 1) }
        else { wantsPlay = false; hasEnded = true; emit("ended"); emit() }
    }
    private func loadArtwork() {
        artworkTask?.cancel()
        artwork = nil
        guard let entry = current, let url = URL(string: entry.cover), url.scheme == "https" else { return }
        let key = entry.key, rev = revision
        artworkTask = URLSession.shared.dataTask(with: url) { [weak self] data, _, _ in
            guard let data, data.count < 8 * 1024 * 1024, let image = UIImage(data: data) else { return }
            DispatchQueue.main.async {
                guard let self, self.current?.key == key, self.revision == rev else { return }
                self.artwork = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
                self.updateNowPlaying()
            }
        }
        artworkTask?.resume()
    }
    private func updateNowPlaying() {
        guard let entry = current else { MPNowPlayingInfoCenter.default().nowPlayingInfo = nil; return }
        var info: [String: Any] = [MPMediaItemPropertyTitle: entry.title, MPMediaItemPropertyArtist: entry.artists,
            MPNowPlayingInfoPropertyElapsedPlaybackTime: milliseconds(player.currentTime()) / 1000,
            MPMediaItemPropertyPlaybackDuration: player.currentItem.map { milliseconds($0.duration) / 1000 } ?? 0,
            MPNowPlayingInfoPropertyPlaybackRate: player.timeControlStatus == .playing ? speed : 0,
            MPNowPlayingInfoPropertyDefaultPlaybackRate: speed,
            MPNowPlayingInfoPropertyPlaybackQueueIndex: selected,
            MPNowPlayingInfoPropertyPlaybackQueueCount: entries.count]
        if let artwork { info[MPMediaItemPropertyArtwork] = artwork }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    @objc func getState(_ call: CAPPluginCall) { onMain(call) { call.resolve(self.snapshot()) } }
    @objc func setQueue(_ call: CAPPluginCall) {
        onMain(call) {
            guard let rows = call.getArray("items", JSObject.self), let revision = call.getString("revision") else { call.reject("Invalid queue"); return }
            var keys = Set<String>()
            var next: [Entry] = []
            for row in rows {
                guard let key = row["key"] as? String, keys.insert(key).inserted else { call.reject("Invalid queue key"); return }
                next.append(Entry(key: key, title: row["title"] as? String ?? "", artists: row["artists"] as? String ?? "", cover: row["coverUrl"] as? String ?? "", url: (row["url"] as? String).flatMap(self.validURL)))
            }
            let old = self.current
            let requested = call.getString("selectedKey")
            // Keep playback and cached native sources when JS only edits the queue.
            for index in next.indices where next[index].url == nil {
                if let cached = self.entries.first(where: { $0.key == next[index].key }) {
                    next[index].url = cached.url; next[index].expires = cached.expires
                }
            }
            let oldPosition = self.milliseconds(self.player.currentTime())
            let wasPlaying = self.wantsPlay
            self.entries = next
            self.revision = revision
            if next.isEmpty { self.clear(); call.resolve(self.snapshot()); return }
            let index = next.firstIndex(where: { $0.key == (requested ?? old?.key) }) ?? 0
            if requested == nil, old?.key == next[index].key, self.player.currentItem != nil {
                self.selected = index; self.emit()
            } else {
                self.choose(index, position: requested == nil ? oldPosition : call.getDouble("positionMs") ?? 0)
                if requested == nil && !wasPlaying { self.pausePlayback() }
            }
            call.resolve(self.snapshot())
        }
    }
    @objc func select(_ call: CAPPluginCall) {
        onMain(call) {
            guard let key = call.getString("key"), let index = self.entries.firstIndex(where: { $0.key == key }) else { call.reject("Unknown track"); return }
            self.choose(index, position: call.getDouble("positionMs") ?? 0)
            call.resolve(self.snapshot())
        }
    }
    @objc func supplySource(_ call: CAPPluginCall) {
        onMain(call) {
            guard call.getString("revision") == self.revision,
                  let key = call.getString("key"), let index = self.entries.firstIndex(where: { $0.key == key }) else { call.resolve(); return }
            guard let value = call.getString("url"), let url = self.validURL(value) else { call.reject("Unsupported audio URL"); return }
            self.entries[index].url = url
            self.entries[index].expires = call.getDouble("expiresAt") ?? 0
            if index == self.selected && self.player.currentItem == nil { self.loadSelected(position: self.pendingPosition) }
            call.resolve()
        }
    }
    @objc func failSource(_ call: CAPPluginCall) {
        onMain(call) {
            if call.getString("revision") == self.revision && call.getString("key") == self.current?.key { self.fail("Nie udało się pobrać źródła audio.") }
            call.resolve()
        }
    }
    @objc func next(_ call: CAPPluginCall) { onMain(call) { self.advance(1); call.resolve(self.snapshot()) } }
    @objc func previous(_ call: CAPPluginCall) { onMain(call) { self.advance(-1); call.resolve(self.snapshot()) } }
    @objc func play(_ call: CAPPluginCall) { onMain(call) { self.start(); call.resolve(self.snapshot()) } }
    @objc func pause(_ call: CAPPluginCall) { onMain(call) { self.pausePlayback(); call.resolve(self.snapshot()) } }
    private func clear() {
        generation += 1; sourceTimeout?.cancel(); artworkTask?.cancel(); itemObservation = nil
        wantsPlay = false; resumeAfterInterruption = false; hasEnded = false
        player.pause(); player.replaceCurrentItem(with: nil)
        entries = []; selected = -1; revision = ""; errorText = nil; pendingPosition = 0
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
        emit()
    }
    @objc func stop(_ call: CAPPluginCall) { onMain(call) { self.clear(); call.resolve(self.snapshot()) } }
    @objc func seek(_ call: CAPPluginCall) { onMain(call) { self.seekTo(call.getDouble("positionMs") ?? 0); call.resolve(self.snapshot()) } }
    @objc func configure(_ call: CAPPluginCall) {
        onMain(call) {
            self.player.volume = Float(min(1, max(0, call.getDouble("volume") ?? 1)))
            self.speed = Float(min(2, max(0.5, call.getDouble("speed") ?? 1)))
            self.repeatMode = call.getString("repeat") ?? "off"
            if self.player.timeControlStatus == .playing { self.player.rate = self.speed }
            self.emit(); call.resolve(self.snapshot())
        }
    }
    @objc func cacheAudio(_ call: CAPPluginCall) {
        guard let base64 = call.getString("data"), base64.count <= 180 * 1024 * 1024 else { call.reject("Audio cache input too large"); return }
        let ext = call.getString("extension") ?? "audio"
        guard ["m4a", "mp3", "aac", "flac", "wav", "audio"].contains(ext) else { call.reject("Unsupported cache format"); return }
        let folder = cacheFolder
        DispatchQueue.global(qos: .utility).async {
            do {
                guard let data = Data(base64Encoded: base64) else { call.reject("Invalid audio data"); return }
                try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
                let files = try FileManager.default.contentsOfDirectory(at: folder, includingPropertiesForKeys: [.fileSizeKey])
                let bytes = files.reduce(0) { $0 + ((try? $1.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0) }
                guard bytes + data.count <= 512 * 1024 * 1024 else { call.reject("Pamięć podręczna audio jest pełna. Uruchom aplikację ponownie."); return }
                let url = folder.appendingPathComponent(UUID().uuidString).appendingPathExtension(ext)
                try data.write(to: url, options: .atomic)
                call.resolve(["url": url.absoluteString])
            } catch { call.reject(error.localizedDescription) }
        }
    }
    deinit {
        sourceTimeout?.cancel(); artworkTask?.cancel()
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        notifications.forEach { NotificationCenter.default.removeObserver($0) }
        remoteTargets.forEach { $0.0.removeTarget($0.1) }
    }
}
