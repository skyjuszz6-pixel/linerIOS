import Capacitor

final class LinerViewController: CAPBridgeViewController {
    override func capacitorDidLoad() {
        bridge?.registerPluginInstance(LinerAudioPlugin())
        bridge?.registerPluginInstance(OfflineAudioPlugin())
        bridge?.registerPluginInstance(LinerToolsPlugin())
    }
}
