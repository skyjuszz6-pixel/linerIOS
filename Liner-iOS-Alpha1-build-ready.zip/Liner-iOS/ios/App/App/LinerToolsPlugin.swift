import UIKit
import Capacitor

@objc(LinerToolsPlugin)
public final class LinerToolsPlugin: CAPPlugin, CAPBridgedPlugin {
    public let identifier = "LinerToolsPlugin"
    public let jsName = "LinerTools"
    public let pluginMethods = [CAPPluginMethod(name: "share", returnType: CAPPluginReturnPromise)]
    @objc func share(_ call: CAPPluginCall) {
        guard let text = call.getString("text"), !text.isEmpty else { call.reject("Brak tekstu"); return }
        DispatchQueue.main.async {
            guard let presenter = self.bridge?.viewController else { call.reject("Brak widoku"); return }
            let sheet = UIActivityViewController(activityItems: [text], applicationActivities: nil)
            sheet.popoverPresentationController?.sourceView = presenter.view
            sheet.popoverPresentationController?.sourceRect = CGRect(x: presenter.view.bounds.midX, y: presenter.view.bounds.midY, width: 1, height: 1)
            sheet.completionWithItemsHandler = { _, _, _, error in
                if let error { call.reject(error.localizedDescription) } else { call.resolve() }
            }
            presenter.present(sheet, animated: true)
        }
    }
}
