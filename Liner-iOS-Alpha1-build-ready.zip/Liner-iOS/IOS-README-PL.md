# Liner — iOS Alpha 1 (port źródłowy)

To pierwszy port kodu na iOS, **nie podpisana aplikacja IPA ani wydanie przetestowane na iPhonie**.
Baza: udostępnione źródła `Liner-Android-v1.2-in-progress-source.zip`, wersja pliku 2.
Nazwa tej bazy nie oznacza, że wcześniejsze zadania Androida zostały ukończone.
W tej paczce są wspólny frontend i nowy projekt iOS; katalog Androida pominięto.

## Co jest zaimplementowane

- Projekt Xcode z Capacitor 8.5.3, Swift Package Manager i rejestracją lokalnych pluginów w `LinerViewController` oraz `SceneDelegate`.
- `LinerAudio`: jeden AVPlayer, kolejka, play/pause, następny/poprzedni, seek, repeat off/one/all, głośność, tempo 0,5–2× z zachowaniem tonacji.
- Audio session `.playback`, tryb audio w tle, metadane/okładka w Now Playing, systemowe komendy odtwarzania; pauza po utracie słuchawek i obsługa przerwań sesji.
- Ochrona przed spóźnionymi odpowiedziami po zmianie kolejki/utworu, limity cache i kontrola wygasania dostarczonych URL.
- `OfflineAudio`: systemowy wybór plików, kopia do prywatnego katalogu aplikacji, metadane audio, trwały indeks, lista i usuwanie. Import odrzuca pliki nieodtwarzalne przez AVFoundation. Limit 100 plików/import i 512 MiB/plik.
- Systemowy arkusz udostępniania, także z poprawnym zakotwiczeniem na iPadzie.
- Interfejs wspólny z Androidem, viewport-fit i safe areas, poprawne komunikaty wersji iOS, oryginalne logo w ikonie i ekranie startowym.
- Preferencja AAC przy rozwiązywaniu źródeł YouTube; pomijanie niezgodnego kontenera z backendu Linera. Jawny błąd zamiast wysyłania WebM/Ogg do AVPlayer.
- Ustawienia Discord RPC, osobnej tonacji i reverb nie udają dostępnych funkcji iOS. Ręczne udostępnianie działa przez natywny arkusz.

## Uruchomienie na Macu

Wymagania: Node 22+ (tu zweryfikowano Node 24), Xcode 26+, iOS 15+.

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm run ios:sync
npm run ios:open
```

W Xcode wybierz schemat `App`, symulator lub podłączony iPhone. Dla fizycznego urządzenia w Signing & Capabilities wybierz własny Team i ustaw unikalny Bundle Identifier zamiast testowego `local.personal.liner.alpha2`, jeśli Xcode tego wymaga. Ustawienie dotyczy też `capacitor.config.ts`, gdy zmieniasz identyfikator projektu. Uruchom przyciskiem Run.

Pełna kompilacja kontrolna bez podpisu, dla symulatora:

```sh
bash scripts/verify-ios.sh
```

Dla dystrybucji IPA potrzebne są właściwe uprawnienia/podpisanie w Xcode i profil zgodny z wybraną metodą dystrybucji. W paczce nie ma certyfikatów, profili ani konta Apple. Nie wysłano nic do App Store ani TestFlight.

## Weryfikacja wykonana tutaj

- Kompilacja frontendu i `cap sync ios`: PASS.
- TypeScript `tsc --noEmit`: PASS.
- 37 testów mobilnych: PASS; dodatkowo 15 testów kontrolki tempa/tonacji i wyboru formatów oraz 10 testów resolverów: PASS (łącznie 62).
- Parser projektu Xcode, plist, storyboard i kontrola przypisania plików Swift do targetu: PASS. Parser składni Swift: PASS (nie zastępuje kompilacji).
- Podgląd przeglądarkowy UI niewykonany: pobranie przeglądarki testowej było niedostępne.
- Wyniki komend: `verification-ios/`.
- **Kompilacja Swift/Xcode, symulator, fizyczny iPhone, faktyczne streamowanie, Bluetooth/AirPlay oraz audio w tle: jeszcze niewykonane.** Ten runtime jest linuksowy i nie ma SDK Apple. Testy JS symulują bridge, nie dekoder iOS.

## Ograniczenia tej alfy

1. Rozwiązywanie internetowych źródeł nadal odbywa się w JavaScript. iOS może uśpić WebView. Natywnie odtwarzana jest już przygotowana kolejka (frontend przygotowuje do 20 następnych pozycji). Długi odsłuch, nowe/wygasłe adresy i automatyczne rekomendacje po końcu kolejki mogą wymagać ponownego otwarcia aplikacji. To nie jest jeszcze pełna, niezależna od WebView usługa rozwiązywania źródeł.
2. Zmiany między utworami używają AVPlayer i nie są deklarowane jako bezprzerwowe. Konieczny pomiar na urządzeniu. Odtwarzanie online zależy od dostępności backendu, sesji użytkownika i zgodnego źródła AAC/MP3/HLS; nie potwierdzono dostępności usług.
3. Część formatów obsługiwanych przez Androida nie jest dopuszczona w tej alfie iOS. Brak transkodowania. Pliki offline sprawdzane są przez system podczas importu.
4. Cache blobów ma limit 512 MiB, pojedyncze wejście base64 około 180 MiB. Jest czyszczony przy nowym uruchomieniu natywnego pluginu; biblioteka offline pozostaje. Nie ma jeszcze zarządzania cache w interfejsie.
5. Brak niezależnej zmiany tonacji, reverb, automatycznego Discord Presence, CarPlay oraz własnej Live Activity. Systemowe Now Playing nie jest osobną implementacją Dynamic Island.
6. Playlisty i stan frontendu zachowują dotychczasowy mechanizm aplikacji. Nie obiecujemy samoczynnego wznowienia po wymuszonym zamknięciu procesu.

## Testy wymagane przed wydaniem

| Scenariusz | Oczekiwany wynik |
| --- | --- |
| Import MP3/AAC/FLAC/WAV z aplikacji Pliki, anulowanie, pusty/uszkodzony/za duży plik | Poprawne pliki na liście, anulowanie bez błędu, odrzucone pliki liczone, interfejs pozostaje responsywny |
| Tryb samolotowy po imporcie, restart aplikacji | Biblioteka i odtwarzanie lokalnych plików działają; po usunięciu znika tylko kopia Linera |
| Play/pause, seek, tempo 0,5×/1×/2× | Dźwięk i postęp odpowiadają stanowi UI; tempo nie zmienia wysokości dźwięku |
| 30 szybkich zmian utworu, seek w trakcie ładowania, nowa kolejka w trakcie pobierania | Końcowy utwór jest zgodny z ostatnim poleceniem, brak starego dźwięku/okładki |
| Repeat off/one/all, ostatni utwór, powtórne uruchomienie ostatniego utworu | Poprawne przejścia i pojedyncze zdarzenia końca; brak samoczynnych podwójnych przeskoków |
| Zablokowanie ekranu na 30–60 min, kolejka offline oraz online >20 utworów | Zmierzyć ciągłość i sprawdzić limit przygotowanych źródeł; nie uznawać online za gotowe przed tym testem |
| Pauza/wznowienie/skip/seek z ekranu blokady i Control Center | Ten sam utwór i postęp w systemie oraz po powrocie do UI |
| Rozmowa telefoniczna, alarm, odłączenie słuchawek/Bluetooth | Brak nakładania audio, odłączenie pauzuje, wznowienie respektuje decyzję systemu i ręczną pauzę |
| AirPlay, ponowne podłączenie słuchawek | Poprawny routing bez uruchomienia drugiego odtwarzacza |
| Brak sieci, 403/404, wygasły URL, nieobsługiwany kontener | Czytelny błąd, brak udawanego stanu odtwarzania i możliwość ponowienia |
| iPhone SE, iPhone z wycięciem, iPad, obrót, klawiatura | Przyciski nie pod home indicator, brak poziomego przewijania, arkusz udostępniania nie powoduje crasha |

## Dokumentacja użyta przy implementacji

- https://capacitorjs.com/docs/ios
- https://capacitorjs.com/docs/ios/custom-code
- https://capacitorjs.com/docs/getting-started/environment-setup
- https://developer.apple.com/documentation/avfoundation/configuring-your-app-for-media-playback
- https://developer.apple.com/documentation/MediaPlayer/MPRemoteCommandCenter

Oryginalne źródła i licencja pozostają w paczce. Frontend oraz adaptery Androida w archiwum bazowym nie zostały uznane za w pełni zweryfikowane przez sam fakt ich istnienia.

## Budowanie IPA przez GitHub Actions

Konfiguracja: `.github/workflows/ios-ipa.yml`. Umieść zawartość katalogu Liner-iOS w głównym katalogu prywatnego repozytorium. Workflow można uruchomić ręcznie na domyślnej gałęzi (Actions → Build Liner iOS IPA → Run workflow) albo pushem do gałęzi `ios-build/...`. Runner macos-26 kompiluje kod dla fizycznego urządzenia arm64, a dopiero po sukcesie pakuje `Payload/App.app` do IPA. Artefakt jest przechowywany 7 dni.

**Status: konfiguracja przygotowana i sprawdzona składniowo, ale zdalny build jeszcze nie został uruchomiony.** Integracja GitHub nie udostępniła żadnych repozytoriów. Nie wygenerowano IPA.

Wynik `Liner-iOS-Alpha1-unsigned.ipa` będzie niepodpisany i wymaga podpisania przed instalacją. Workflow nie publikuje wydań, nie wysyła aplikacji do App Store/TestFlight i nie używa certyfikatów.
