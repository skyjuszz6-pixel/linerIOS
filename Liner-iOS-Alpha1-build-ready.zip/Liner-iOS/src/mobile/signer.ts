import { SIGNER_WASM_BASE64 } from "../../electron/signer";

export interface SignRequestInput {
  method: string;
  path: string;
  body?: string | null;
  timestamp?: number;
}

export interface SignedRequestHeaders {
  signature: string;
  timestamp: number;
  nonce: string;
}

// maintains clock delta between client and server (ms)
let serverTimeOffsetMs = 0;

export function setServerTimeOffset(offsetMs: number): void {
  if (Number.isFinite(offsetMs)) {
    serverTimeOffsetMs = offsetMs;
  }
}

// parses date header from server response and calculates clock delta
export function syncServerTime(dateHeaderOrMs: string | number | Date): number {
  const serverMs =
    typeof dateHeaderOrMs === "number"
      ? dateHeaderOrMs
      : typeof dateHeaderOrMs === "string"
        ? Date.parse(dateHeaderOrMs)
        : dateHeaderOrMs.getTime();

  if (!Number.isNaN(serverMs) && serverMs > 0) {
    serverTimeOffsetMs = serverMs - Date.now();
  }
  return serverTimeOffsetMs;
}

export function getServerTimeOffset(): number {
  return serverTimeOffsetMs;
}

export function getAdjustedTimestamp(): number {
  return Math.floor((Date.now() + serverTimeOffsetMs) / 1000);
}

interface WasmSignerExports {
  liner_alloc: (len: number) => number;
  liner_dealloc: (ptr: number, len: number) => void;
  liner_get_result_ptr: () => number;
  liner_get_result_len: () => number;
  liner_sign_cover_url: (ptr: number, len: number) => number;
  liner_sign_request: (
    method_ptr: number,
    method_len: number,
    path_ptr: number,
    path_len: number,
    body_ptr: number,
    body_len: number,
    timestamp: bigint,
    nonce_ptr: number,
    nonce_len: number,
  ) => number;
  liner_sign_monitor_request: (
    method_ptr: number,
    method_len: number,
    path_ptr: number,
    path_len: number,
    body_ptr: number,
    body_len: number,
    timestamp: bigint,
    nonce_ptr: number,
    nonce_len: number,
  ) => number;
  liner_sign_raw_payload: (ptr: number, len: number) => number;
  memory: WebAssembly.Memory;
}

let wasmExportsInstance: WasmSignerExports | null = null;
function getWasmExports(): WasmSignerExports {
  if (wasmExportsInstance) return wasmExportsInstance;

  const wasmBuffer = Uint8Array.from(atob(SIGNER_WASM_BASE64), (c) =>
    c.charCodeAt(0),
  );
  const wasmModule = new WebAssembly.Module(wasmBuffer);
  const wasmInstance = new WebAssembly.Instance(wasmModule, {});
  wasmExportsInstance = wasmInstance.exports as unknown as WasmSignerExports;
  return wasmExportsInstance;
}

function passStringToWasm(
  exports: WasmSignerExports,
  str: string,
): { ptr: number; len: number; free: () => void } {
  const bytes = new TextEncoder().encode(str);
  const ptr = exports.liner_alloc(bytes.length);
  const memoryView = new Uint8Array(exports.memory.buffer, ptr, bytes.length);
  memoryView.set(bytes);
  return {
    ptr,
    len: bytes.length,
    free: () => exports.liner_dealloc(ptr, bytes.length),
  };
}

function readResultFromWasm(exports: WasmSignerExports): string {
  const ptr = exports.liner_get_result_ptr();
  const len = exports.liner_get_result_len();
  if (!ptr || len === 0) return "";
  const memoryView = new Uint8Array(exports.memory.buffer, ptr, len);
  return new TextDecoder().decode(memoryView);
}

// signs cover url token via in-memory wasm
export function signCoverUrl(payload: string): string {
  const wasm = getWasmExports();
  const payloadBuf = passStringToWasm(wasm, payload);
  try {
    const code = wasm.liner_sign_cover_url(payloadBuf.ptr, payloadBuf.len);
    if (code !== 0) {
      throw new Error(`wasm sign_cover_url failed with code ${code}`);
    }
    return readResultFromWasm(wasm);
  } finally {
    payloadBuf.free();
  }
}

// signs api request with canonical string and hmac-sha256 using server-adjusted timestamp
export function signRequest(input: SignRequestInput): SignedRequestHeaders {
  const timestamp = input.timestamp ?? getAdjustedTimestamp();
  const nonce = Array.from(
    globalThis.crypto.getRandomValues(new Uint8Array(8)),
    (b) => b.toString(16).padStart(2, "0"),
  ).join("");

  const wasm = getWasmExports();

  const methodBuf = passStringToWasm(wasm, input.method);
  const pathBuf = passStringToWasm(wasm, input.path);
  const bodyBuf = passStringToWasm(wasm, input.body ?? "");
  const nonceBuf = passStringToWasm(wasm, nonce);

  try {
    const code = wasm.liner_sign_request(
      methodBuf.ptr,
      methodBuf.len,
      pathBuf.ptr,
      pathBuf.len,
      bodyBuf.ptr,
      bodyBuf.len,
      BigInt(timestamp),
      nonceBuf.ptr,
      nonceBuf.len,
    );

    if (code !== 0) {
      throw new Error(`wasm sign_request failed with code ${code}`);
    }

    const signature = readResultFromWasm(wasm);
    return {
      signature,
      timestamp,
      nonce,
    };
  } finally {
    methodBuf.free();
    pathBuf.free();
    bodyBuf.free();
    nonceBuf.free();
  }
}

// signs monitor telemetry request using server-adjusted timestamp
export function signMonitorRequest(
  input: SignRequestInput,
): SignedRequestHeaders {
  const wasm = getWasmExports();
  const timestamp = input.timestamp ?? getAdjustedTimestamp();
  const nonce = Array.from(
    globalThis.crypto.getRandomValues(new Uint8Array(8)),
    (b) => b.toString(16).padStart(2, "0"),
  ).join("");

  const methodBuf = passStringToWasm(wasm, input.method);
  const pathBuf = passStringToWasm(wasm, input.path);
  const bodyBuf = passStringToWasm(wasm, input.body ?? "");
  const nonceBuf = passStringToWasm(wasm, nonce);

  try {
    const code = wasm.liner_sign_monitor_request(
      methodBuf.ptr,
      methodBuf.len,
      pathBuf.ptr,
      pathBuf.len,
      bodyBuf.ptr,
      bodyBuf.len,
      BigInt(timestamp),
      nonceBuf.ptr,
      nonceBuf.len,
    );

    if (code !== 0) {
      throw new Error(`wasm sign_monitor_request failed with code ${code}`);
    }

    const signature = readResultFromWasm(wasm);
    return {
      signature,
      timestamp,
      nonce,
    };
  } finally {
    methodBuf.free();
    pathBuf.free();
    bodyBuf.free();
    nonceBuf.free();
  }
}

// signs raw byte buffer
export function signRawPayload(payload: Uint8Array): string {
  const wasm = getWasmExports();
  const bytes = payload;
  const ptr = wasm.liner_alloc(bytes.length);
  const memoryView = new Uint8Array(wasm.memory.buffer, ptr, bytes.length);
  memoryView.set(bytes);
  try {
    const code = wasm.liner_sign_raw_payload(ptr, bytes.length);
    if (code !== 0) {
      throw new Error(`wasm sign_raw_payload failed with code ${code}`);
    }
    return readResultFromWasm(wasm);
  } finally {
    wasm.liner_dealloc(ptr, bytes.length);
  }
}
