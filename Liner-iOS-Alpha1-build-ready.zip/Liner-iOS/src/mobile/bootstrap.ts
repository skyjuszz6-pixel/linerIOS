import { Capacitor } from "@capacitor/core";
import { App } from "@capacitor/app";
import type { LinerElectronApi } from "../../electron/preload";
import * as signer from "./signer";
import "./mobile.css";
import { installMobileTransport } from "./transport";

const noop = () => {};
const subscribe = () => noop;
const done = async () => {};
const unavailable = async () => false;
const unsupported = async () => {
  throw new Error("This desktop feature is unavailable in the mobile app.");
};

export async function initMobile() {
  const platform = Capacitor.getPlatform();
  installMobileTransport();
  document.documentElement.dataset.platform = platform;
  document.documentElement.dataset.mobile = "true";
  // Explicit adapter: missing features fail, never report fabricated success.
  const bridge: Partial<LinerElectronApi> = {
    platform,
    isHyprland: false,
    signRequest: async (input) => signer.signRequest(input),
    signMonitorRequest: async (input) => signer.signMonitorRequest(input),
    signCoverUrl: async (input) => signer.signCoverUrl(input),
    signRawPayload: async (input) =>
      signer.signRawPayload(new Uint8Array(input)),
    syncServerTime: async (input) => signer.syncServerTime(input),
    getServerTimeOffset: async () => signer.getServerTimeOffset(),
    isMaximized: async () => true,
    isFullScreen: async () => false,
    onWindowStateChange: subscribe,
    onWindowRestored: subscribe,
    onWindowMinimized: subscribe,
    minimize: async () => {
      if (Capacitor.getPlatform() === "android") await App.minimizeApp();
    },
    close: async () => {
      if (Capacitor.getPlatform() === "android") await App.minimizeApp();
    },
    toggleMaximize: done,
    toggleFullScreen: done,
    dragStart: noop,
    dragMove: noop,
    dragEnd: noop,
    onDeeplink: subscribe,
    setAppIcon: done,
    getAppVersion: async () => __APP_VERSION__,
    openDownloads: unavailable,
    openExportFolder: unavailable,
    openCacheFolder: unavailable,
    getCacheStats: unsupported,
    clearCoversCache: unsupported,
    clearAudioCache: unsupported,
    clearHttpCache: unsupported,
    checkForUpdates: async () => ({
      available: false,
      error: "Install mobile updates through your distribution channel.",
    }),
    downloadUpdate: async () => ({
      success: false,
      error: "Desktop updater is disabled on mobile.",
    }),
    quitAndInstall: unavailable,
    onUpdateAvailable: subscribe,
    onUpdateDownloadProgress: subscribe,
    onUpdateDownloaded: subscribe,
    onUpdateError: subscribe,
    bundleCheck: async () => ({
      available: false,
      reason: "Mobile uses bundled assets.",
    }),
    bundleDownloadAndInstall: async () => ({
      success: false,
      error: "Desktop bundles cannot be installed on mobile.",
    }),
    bundleHotSwap: unavailable,
    bundleRollback: unavailable,
    bundleGetStatus: async () => ({
      appVersion: __APP_VERSION__,
      bundleVersion: __APP_VERSION__,
      isOta: false,
      sha256: null,
      effectivePath: `${platform}-assets`,
    }),
    onBundleAvailable: subscribe,
    onBundleDownloadProgress: subscribe,
    onBundleReady: subscribe,
    onBundleStamp: subscribe,
    touchbarUpdateState: noop,
    onTouchBarAction: subscribe,
    sendTouchBarAction: noop,
    getTouchBarInitialState: async () => null,
    onTouchBarRequestSync: subscribe,
    overlayUpdateState: noop,
    overlayReady: noop,
    onOverlayAction: subscribe,
    sendOverlayAction: noop,
    toggleOverlay: unavailable,
    isOverlayOpen: unavailable,
    closeOverlay: noop,
    onOverlayState: subscribe,
    getOverlayInitialState: async () => null,
    updateOverlaySettings: noop,
    pauseOverlayShortcuts: noop,
    onOverlaySettingsChanged: subscribe,
    onOverlayVisibility: subscribe,
    setOverlayAuthenticated: noop,
    discordUpdateState: noop,
    discordUpdateSettings: noop,
    getDiscordStatus: async () => ({ connected: false }),
    mintPoToken: unsupported,
    youtubeTvSession: unsupported,
    youtubeSolveN: unsupported,
  };
  // authSession intentionally omitted: upstream's browser session storage/refresh path is used.
  window.linerElectron = bridge as LinerElectronApi;
  if (Capacitor.getPlatform() === "android") {
    await App.addListener("backButton", ({ canGoBack }) => {
      const event = new KeyboardEvent("keydown", {
        key: "Escape",
        code: "Escape",
        bubbles: true,
        cancelable: true,
      });
      document.dispatchEvent(event);
      if (event.defaultPrevented) return;
      if (canGoBack) window.history.back();
      else void App.minimizeApp();
    });
  }
}
