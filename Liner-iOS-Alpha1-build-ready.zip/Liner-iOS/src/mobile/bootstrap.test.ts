import { beforeEach, describe, expect, it, vi } from "vitest";
const listeners = vi.hoisted(() => ({
  back: null as null | ((event: { canGoBack: boolean }) => void),
  minimize: vi.fn(),
  platform: "android",
}));
vi.mock("@capacitor/core", () => ({
  Capacitor: {
    isNativePlatform: () => true,
    getPlatform: () => listeners.platform,
  },
}));
vi.mock("@capacitor/app", () => ({
  App: {
    minimizeApp: listeners.minimize,
    addListener: vi.fn(async (_name, callback) => {
      listeners.back = callback;
      return { remove: async () => {} };
    }),
  },
}));
import { initMobile } from "./bootstrap";
beforeEach(() => {
  vi.stubGlobal("__APP_VERSION__", "0.2.10");
  listeners.minimize.mockClear();
  listeners.platform = "android";
  listeners.back = null;
});
describe("Android integration", () => {
  it("installs the native adapter without desktop updater or unsupported YouTube success", async () => {
    await initMobile();
    expect(document.documentElement.dataset.mobile).toBe("true");
    expect(await window.linerElectron!.isMaximized()).toBe(true);
    expect(window.linerElectron!.authSession).toBeUndefined();
    expect(await window.linerElectron!.downloadUpdate()).toMatchObject({
      success: false,
    });
    await expect(window.linerElectron!.mintPoToken("test")).rejects.toThrow(
      "unavailable",
    );
  });
  it("lets modal Escape handling consume Android Back before minimizing", async () => {
    await initMobile();
    const consume = (event: KeyboardEvent) => event.preventDefault();
    document.addEventListener("keydown", consume);
    listeners.back!({ canGoBack: false });
    expect(listeners.minimize).not.toHaveBeenCalled();
    document.removeEventListener("keydown", consume);
    listeners.back!({ canGoBack: false });
    expect(listeners.minimize).toHaveBeenCalledOnce();
  });
});

it("iOS reports its platform and never registers Android Back or minimize", async () => {
  listeners.platform = "ios";
  await initMobile();
  expect(window.linerElectron!.platform).toBe("ios");
  expect(document.documentElement.dataset.platform).toBe("ios");
  expect(listeners.back).toBeNull();
  await window.linerElectron!.minimize();
  await window.linerElectron!.close();
  expect(listeners.minimize).not.toHaveBeenCalled();
});
