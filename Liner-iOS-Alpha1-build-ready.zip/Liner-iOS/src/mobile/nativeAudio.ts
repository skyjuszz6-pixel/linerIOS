import { Capacitor, registerPlugin } from "@capacitor/core";
import { usePlayerStore } from "@/features/player/store/playerStore";
import { resolvePlaybackStream } from "@/features/player/engine/streamResolver";
import { linerDb } from "@/shared/storage";
import type { Track } from "@/shared/types";
import { isIOSAudioFormat, audioCacheExtension } from "./audioFormats";
interface State {
  key: string;
  revision: string;
  status?: "playing" | "paused" | "loading" | "error";
  positionMs?: number;
  durationMs?: number;
  error?: string;
  ended?: boolean;
  reason?: number;
}
interface Item {
  key: string;
  title: string;
  artists: string;
  coverUrl: string;
  url?: string;
}
interface Bridge {
  addListener(event: string, callback: (data: any) => void): Promise<unknown>;
  getState(): Promise<State>;
  setQueue(o: {
    items: Item[];
    revision: string;
    selectedKey?: string;
    positionMs?: number;
  }): Promise<State>;
  select(o: { key: string; positionMs: number }): Promise<State>;
  supplySource(o: {
    key: string;
    revision: string;
    url: string;
    expiresAt?: number;
  }): Promise<void>;
  failSource(o: { key: string; revision: string }): Promise<void>;
  next(): Promise<State>;
  previous(): Promise<State>;
  play(): Promise<State>;
  pause(): Promise<State>;
  stop(): Promise<State>;
  seek(o: { positionMs: number }): Promise<State>;
  configure(o: {
    volume: number;
    speed: number;
    pitch: number;
    repeat: string;
  }): Promise<State>;
  cacheAudio(o: { data: string; extension?: string }): Promise<{ url: string }>;
}
export const nativeAudio = registerPlugin<Bridge>("LinerAudio");
const keyFor = (track: Track, index: number) => `${index}:${track.id}`;
export class NativeAudioRuntime {
  public onEnded?: () => void;
  public onError?: (i: { trackId: string; message: string }) => void;
  private ready: Promise<void>;
  private commands: Promise<unknown> = Promise.resolve();
  private queue: Track[] = [];
  private revision = "";
  private serial = 0;
  private currentId: string | null = null;
  private desiredKey: string | null = null;
  private pending = 0;
  private epoch = 0;
  private active = 0;
  private tasks: string[] = [];
  private resolving = new Map<string, AbortController>();
  private supplied = new Set<string>();
  private cache = new Map<string, { url: string; expires: number }>();
  private lastEnded = "";
  private applying = false;
  private lastError = "";
  constructor() {
    this.ready = this.connect();
    this.ready.catch((e) => this.fail(e));
    usePlayerStore.subscribe((s, p) => {
      if (
        s.volume !== p.volume ||
        s.playbackRate !== p.playbackRate ||
        s.pitchSemitones !== p.pitchSemitones ||
        s.isPitchLinked !== p.isPitchLinked ||
        s.repeat !== p.repeat
      )
        void this.configure();
      if (s.queue !== p.queue && !this.applying)
        queueMicrotask(() => {
          if (this.queue !== usePlayerStore.getState().queue && this.currentId)
            void this.syncQueue().catch((e) => this.fail(e));
        });
    });
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible")
        void this.ready
          .then(() => nativeAudio.getState())
          .then((s) => this.accept(s))
          .catch((e) => this.fail(e));
    });
  }
  private enqueue<T>(op: () => Promise<T>): Promise<T> {
    const task = this.commands.then(() => this.ready).then(op);
    this.commands = task.catch(() => {});
    return task;
  }
  private async connect() {
    await nativeAudio.addListener("state", (s: State) => this.accept(s));
    await nativeAudio.addListener("transition", (s: State) => {
      if (s.revision !== this.revision) return;
      if (s.reason === 1 || s.reason === 0) this.onEnded?.();
      this.accept(s);
    });
    await nativeAudio.addListener(
      "sourceNeeded",
      (s: { key: string; revision: string }) => {
        if (s.revision !== this.revision) return;
        this.supplied.delete(s.key);
        this.schedule([s.key], true);
      },
    );
    await nativeAudio.addListener("ended", (s: State) => {
      if (s.revision !== this.revision || s.key === this.lastEnded) return;
      this.lastEnded = s.key;
      this.onEnded?.();
      const state = usePlayerStore.getState();
      if (
        state.currentIndex === state.queue.length - 1 &&
        state.repeat === "off"
      ) {
        state.setStatus("paused");
        if (state.autoplaySimilar && !state.currentTrack?.localUrl)
          state.dispatch({ type: "SKIP_NEXT", isAutoEnd: true });
      }
    });
    const s = await nativeAudio.getState(),
      store = usePlayerStore.getState();
    if (s.key && store.queue.some((t, i) => keyFor(t, i) === s.key)) {
      this.queue = store.queue;
      this.revision = s.revision;
      this.accept(s);
      this.scheduleAhead();
    }
  }
  private accept(s: State) {
    if (
      s.revision !== this.revision ||
      !s.key ||
      (this.desiredKey && s.key !== this.desiredKey)
    )
      return;
    const index = this.queue.findIndex((t, i) => keyFor(t, i) === s.key);
    if (index < 0) return;
    this.desiredKey = null;
    const t = this.queue[index],
      store = usePlayerStore.getState();
    this.currentId = t.id;
    if (store.currentIndex !== index || store.currentTrack?.id !== t.id) {
      this.applying = true;
      store.setCurrentTrack(t, index);
      store.setDuration(t.durationMs);
      this.applying = false;
      this.lastEnded = "";
      this.scheduleAhead();
    }
    if (s.error) {
      this.fail(new Error(s.error));
      return;
    }
    this.lastError = "";
    if (s.status === "playing" && !s.ended) this.lastEnded = "";
    if (s.status && store.status !== s.status) store.setStatus(s.status);
    if (Number.isFinite(s.positionMs) && store.positionMs !== s.positionMs)
      store.setPosition(s.positionMs!);
    if (s.durationMs && s.durationMs > 0 && store.durationMs !== s.durationMs)
      store.setDuration(s.durationMs);
  }
  private fail(e: unknown) {
    const message = e instanceof Error ? e.message : String(e);
    usePlayerStore.getState().setStatus("error", message);
    if (this.currentId && message !== this.lastError) {
      this.lastError = message;
      this.onError?.({ trackId: this.currentId, message });
    }
  }
  private async configure() {
    const s = usePlayerStore.getState();
    try {
      await this.ready;
      await nativeAudio.configure({
        volume: s.volume,
        speed: s.playbackRate,
        pitch: s.isPitchLinked
          ? s.playbackRate
          : Math.pow(2, s.pitchSemitones / 12),
        repeat: s.repeat,
      });
    } catch (e) {
      this.fail(e);
    }
  }
  private async syncQueue(selectedKey?: string, positionMs = 0) {
    const store = usePlayerStore.getState();
    if (!store.queue.length) return;
    this.queue = store.queue;
    const revision = (this.revision = `${Date.now()}-${++this.serial}`);
    for (const c of this.resolving.values()) c.abort();
    this.resolving.clear();
    this.tasks = [];
    this.supplied.clear();
    const items = this.queue.map((t, i) => ({
      key: keyFor(t, i),
      title: t.title,
      artists: t.artists,
      coverUrl: t.coverUrl,
      ...(t.localUrl ? { url: t.localUrl } : {}),
    }));
    const state = await this.enqueue(() =>
      nativeAudio.setQueue({ items, revision, selectedKey, positionMs }),
    );
    if (this.revision !== revision) return;
    this.accept(state);
    this.scheduleAhead();
  }
  private scheduleAhead() {
    if (!this.queue.length) return;
    const index = Math.max(0, usePlayerStore.getState().currentIndex);
    const indices = [
      index,
      ...Array.from(
        { length: Math.min(20, this.queue.length) },
        (_, i) => (index + i + 1) % this.queue.length,
      ),
    ];
    const keys = indices.map((i) => keyFor(this.queue[i], i));
    const wanted = new Set(keys);
    // A rapid skip must not wait behind downloads for tracks we already left.
    this.tasks = this.tasks.filter((key) => wanted.has(key));
    for (const [key, controller] of this.resolving) {
      if (!wanted.has(key)) controller.abort();
    }
    const current = keys[0];
    if (
      !this.supplied.has(current) &&
      !this.resolving.has(current) &&
      this.active >= 2
    ) {
      // Reserve a resolver slot for the selected song, even when both slots are
      // occupied by valid future tracks (e.g. after wrapping around the queue).
      const preload = [...this.resolving.entries()].find(
        ([key, c]) => key !== current && !c.signal.aborted,
      );
      preload?.[1].abort();
    }
    this.schedule(keys, true);
  }
  private schedule(keys: string[], priority = false) {
    const valid = keys.filter(
      (k) =>
        this.queue.some((t, i) => keyFor(t, i) === k) &&
        !this.supplied.has(k) &&
        !this.resolving.has(k),
    );
    this.tasks = Array.from(
      new Set(priority ? [...valid, ...this.tasks] : [...this.tasks, ...valid]),
    );
    this.pump();
  }
  private pump() {
    while (this.active < 2 && this.tasks.length) {
      const key = this.tasks.shift()!;
      if (this.resolving.has(key) || this.supplied.has(key)) continue;
      const index = this.queue.findIndex((t, i) => keyFor(t, i) === key);
      if (index < 0) continue;
      const track = this.queue[index],
        revision = this.revision,
        c = new AbortController();
      this.resolving.set(key, c);
      this.active++;
      void this.resolve(track, c.signal)
        .then(async (url) => {
          if (c.signal.aborted || revision !== this.revision) return;
          await nativeAudio.supplySource({
            key,
            revision,
            url,
            expiresAt: track.localUrl ? 0 : this.cache.get(track.id)?.expires,
          });
          if (!c.signal.aborted && revision === this.revision)
            this.supplied.add(key);
        })
        .catch(async (e) => {
          if (!c.signal.aborted && revision === this.revision) {
            await nativeAudio.failSource({ key, revision }).catch(() => {});
            if (
              key ===
              keyFor(
                usePlayerStore.getState().currentTrack ?? track,
                usePlayerStore.getState().currentIndex,
              )
            )
              this.fail(e);
          }
        })
        .finally(() => {
          if (this.resolving.get(key) === c) this.resolving.delete(key);
          this.active--;
          const selected = usePlayerStore.getState();
          if (
            c.signal.aborted &&
            revision === this.revision &&
            selected.currentTrack &&
            key === keyFor(selected.currentTrack, selected.currentIndex)
          )
            this.schedule([key], true);
          this.pump();
        });
    }
  }
  private async resolve(track: Track, signal: AbortSignal) {
    if (track.localUrl) return track.localUrl;
    const old = this.cache.get(track.id);
    if (old && old.expires > Date.now() + 60000) return old.url;
    const stored = await linerDb.getAudio(track.id);
    const ios = Capacitor.getPlatform() === "ios";
    const cached =
      stored && (!ios || isIOSAudioFormat(stored.blob.type)) ? stored : null;
    const stream = cached
      ? { blob: cached.blob, expiresAtMs: null }
      : await resolvePlaybackStream(track, signal, { progressive: false });
    const mime =
      stream.blob?.type || ("mimeType" in stream ? stream.mimeType : "");
    if (ios && !isIOSAudioFormat(mime)) {
      if ("release" in stream) stream.release?.();
      throw new Error(
        "To źródło audio nie jest obsługiwane na iOS. Wybierz AAC, MP3, FLAC lub WAV.",
      );
    }
    let url: string;
    try {
      if (stream.blob) {
        if (signal.aborted) throw new DOMException("Aborted", "AbortError");
        const data = await new Promise<string>((resolve, reject) => {
          const r = new FileReader();
          r.onload = () => resolve(String(r.result).split(",")[1]);
          r.onerror = () => reject(r.error);
          r.readAsDataURL(stream.blob!);
        });
        url = (
          await nativeAudio.cacheAudio({
            data,
            extension: audioCacheExtension(mime),
          })
        ).url;
      } else url = stream.url!;
    } finally {
      if ("release" in stream) stream.release?.();
    }
    this.cache.set(track.id, {
      url,
      expires: stream.expiresAtMs ?? Date.now() + 20 * 60 * 1000,
    });
    while (this.cache.size > 80)
      this.cache.delete(this.cache.keys().next().value!);
    return url;
  }
  getCurrentTrackId() {
    return this.currentId;
  }
  hasLoadedSourceFor(id: string) {
    return this.currentId === id && this.queue.some((t) => t.id === id);
  }
  cancelPendingLoad() {
    this.epoch++;
    this.desiredKey = null;
    void this.enqueue(() => nativeAudio.pause()).catch((e) => this.fail(e));
  }
  async preloadTrack(track: Track) {
    const i = this.queue.findIndex((t) => t.id === track.id);
    if (i >= 0) this.schedule([keyFor(track, i)], true);
  }
  setPendingSeek(ms: number) {
    this.pending = ms;
  }
  async loadAndPlay(track: Track, positionMs = 0, bypassCache = false) {
    const epoch = ++this.epoch;
    this.currentId = track.id;
    this.pending = positionMs;
    this.lastEnded = "";
    this.lastError = "";
    if (bypassCache) this.cache.delete(track.id);
    const store = usePlayerStore.getState();
    let index = store.currentIndex;
    if (store.queue[index]?.id !== track.id)
      index = store.queue.findIndex((t) => t.id === track.id);
    if (index < 0) {
      store.setQueue([track]);
      index = 0;
    }
    this.desiredKey = keyFor(track, index);
    store.setStatus("loading");
    try {
      await this.ready;
      if (epoch !== this.epoch) return;
      await this.configure();
      if (this.queue !== store.queue || !this.revision)
        await this.syncQueue(this.desiredKey, this.pending);
      else {
        const key = this.desiredKey;
        const seekPosition = this.pending;
        this.schedule([key!], true);
        const s = await this.enqueue(() =>
          nativeAudio.select({ key: key!, positionMs: seekPosition }),
        );
        if (epoch === this.epoch) this.accept(s);
      }
      if (epoch === this.epoch) this.scheduleAhead();
    } catch (e) {
      if (epoch === this.epoch) this.fail(e);
    }
  }
  async skipNative(direction: "next" | "previous") {
    if (!this.revision) return false;
    const store = usePlayerStore.getState();
    if (
      direction === "next" &&
      store.currentIndex === store.queue.length - 1 &&
      store.repeat === "off"
    )
      return false;
    this.desiredKey = null;
    try {
      const s = await this.enqueue(() =>
        direction === "next" ? nativeAudio.next() : nativeAudio.previous(),
      );
      this.accept(s);
      return true;
    } catch (e) {
      this.fail(e);
      return true;
    }
  }
  pause() {
    void this.enqueue(() => nativeAudio.pause())
      .then((s) => this.accept(s))
      .catch((e) => this.fail(e));
  }
  resume() {
    void this.enqueue(() => nativeAudio.play())
      .then((s) => this.accept(s))
      .catch((e) => this.fail(e));
  }
  seek(positionMs: number) {
    this.pending = positionMs;
    void this.enqueue(() => nativeAudio.seek({ positionMs }))
      .then((s) => this.accept(s))
      .catch((e) => this.fail(e));
  }
  stop() {
    this.epoch++;
    this.currentId = null;
    this.desiredKey = null;
    this.revision = "";
    this.queue = [];
    this.tasks = [];
    for (const c of this.resolving.values()) c.abort();
    void this.enqueue(() => nativeAudio.stop()).catch((e) => this.fail(e));
  }
}
