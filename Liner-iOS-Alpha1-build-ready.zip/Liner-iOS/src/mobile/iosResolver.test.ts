import { beforeEach, expect, it, vi } from "vitest";
const m = vi.hoisted(() => ({ liner: vi.fn(), direct: vi.fn() }));
vi.mock("@capacitor/core", () => ({ Capacitor: { getPlatform: () => "ios" } }));
vi.mock("@/shared/media/liner/linerPlayback", () => ({
  resolveLinerStream: m.liner,
}));
vi.mock("@/shared/youtube", () => ({
  isYoutubeSignedIn: () => false,
  prefersAccountPlayback: () => false,
  resolveDirectAudioStream: m.direct,
  toVideoId: () => "dQw4w9WgXcQ",
}));
vi.mock("@/shared/media/soundcloud", () => ({
  toSoundCloudTrackId: () => null,
}));
vi.mock("@/features/player/engine/youtubeStandIn", () => ({
  findYoutubeStandIn: vi.fn(),
}));
import { resolvePlaybackStream } from "@/features/player/engine/streamResolver";
const track = {
  id: "yt:dQw4w9WgXcQ",
  title: "Test",
  artists: "Test",
  durationMs: 1000,
};
beforeEach(() => {
  vi.clearAllMocks();
});
it("falls back from backend WebM and explicitly requests AAC", async () => {
  m.liner.mockResolvedValue({
    url: "https://example.org/x.webm",
    mimeType: "audio/webm",
    size: 1024,
  });
  m.direct.mockResolvedValue({
    url: "https://example.org/x.m4a",
    mimeType: "audio/mp4",
    codec: "aac",
    bitrate: 128000,
  });
  const result = await resolvePlaybackStream(track);
  expect(result.url).toBe("https://example.org/x.m4a");
  expect(m.direct).toHaveBeenCalledWith(
    "dQw4w9WgXcQ",
    expect.objectContaining({ preferredCodec: "aac" }),
  );
});
it("uses an iOS-compatible backend source directly", async () => {
  m.liner.mockResolvedValue({
    url: "https://example.org/backend.m4a",
    mimeType: "audio/mp4",
    codec: "aac",
    size: 1024,
  });
  const result = await resolvePlaybackStream(track);
  expect(result.url).toBe("https://example.org/backend.m4a");
  expect(m.direct).not.toHaveBeenCalled();
});
