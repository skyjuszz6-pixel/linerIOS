import {
  memo,
  useEffect,
  useRef,
  useState,
  type CSSProperties,
  type ReactNode,
} from "react";
export default memo(function MobileMarquee({
  children,
  label,
  className = "",
}: {
  children: ReactNode;
  label: string;
  className?: string;
}) {
  const outer = useRef<HTMLSpanElement>(null),
    inner = useRef<HTMLSpanElement>(null);
  const [distance, setDistance] = useState(0),
    [visible, setVisible] = useState(false);
  useEffect(() => {
    const box = outer.current,
      text = inner.current;
    if (!box || !text) return;
    const measure = () =>
      setDistance(Math.max(0, text.scrollWidth - box.clientWidth));
    const resize = new ResizeObserver(measure);
    resize.observe(box);
    resize.observe(text);
    const observer = new IntersectionObserver(([e]) =>
      setVisible(e.isIntersecting),
    );
    observer.observe(box);
    measure();
    return () => {
      resize.disconnect();
      observer.disconnect();
    };
  }, [label]);
  return (
    <span
      ref={outer}
      title={label}
      className={`mobile-marquee ${className}`}
      data-moving={visible && distance > 2}
      style={
        {
          "--marquee-distance": `${-distance}px`,
          "--marquee-duration": `${Math.max(8, distance / 24 + 4)}s`,
        } as CSSProperties
      }
    >
      <span key={label} ref={inner}>
        {children}
      </span>
    </span>
  );
});
