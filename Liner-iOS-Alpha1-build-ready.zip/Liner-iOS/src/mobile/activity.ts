import { Capacitor, registerPlugin } from "@capacitor/core";
export const mobileTools = registerPlugin<{
  share(o: { text: string }): Promise<void>;
}>("LinerTools");
export async function shareActivity(title: string, artists: string) {
  const text = `Słucham w Liner: ${title} — ${artists}`;
  if (Capacitor.isNativePlatform()) await mobileTools.share({ text });
  else if (navigator.share) await navigator.share({ text });
  else await navigator.clipboard.writeText(text);
}
