export function playbackTime(
  position: number,
  elapsed: number,
  rate: number,
  playing: boolean,
  duration: number,
) {
  return Math.min(
    duration > 0 ? duration : Infinity,
    Math.max(0, position + (playing ? Math.max(0, elapsed) * rate : 0)),
  );
}
export function activeLineAt(
  lines: readonly { timeMs: number }[],
  time: number,
) {
  let low = 0,
    high = lines.length;
  while (low < high) {
    const mid = (low + high) >>> 1;
    if (lines[mid].timeMs <= time) low = mid + 1;
    else high = mid;
  }
  return low - 1;
}
export function wordProgress(start: number, end: number, time: number) {
  if (end <= start) return time >= start ? 100 : 0;
  return Math.max(0, Math.min(100, ((time - start) / (end - start)) * 100));
}
