import { memo, useEffect, useRef, useState } from "react";
import { usePlayerStore } from "@/features/player/store/playerStore";
import { playerEngine } from "@/features/player/engine/playerEngine";
import {
  useLyricsStore,
  hasSyncedLyricsSources,
} from "@/features/lyrics/store/lyricsStore";
import { activeLineAt, playbackTime, wordProgress } from "./timing";

/** Native playback clock; no dependency on the desktop HTML audio element. */
export default memo(function MobileLyrics() {
  const lines = useLyricsStore((s) => s.syncedLines);
  const trackId = useLyricsStore((s) => s.currentLyricsTrackId);
  const rawFormat = useLyricsStore((s) => s.rawFormat);
  const providers = useLyricsStore((s) => s.availableProviders);
  const rawLines = useLyricsStore((s) => s.braccatoLyrics);
  const synced = hasSyncedLyricsSources(providers, rawLines, rawFormat);
  const [active, setActive] = useState(-1);
  const [following, setFollowing] = useState(true);
  const container = useRef<HTMLDivElement>(null);
  const buttons = useRef<(HTMLButtonElement | null)[]>([]);
  const followingRef = useRef(true);

  useEffect(() => {
    setActive(-1);
    setFollowing(true);
    followingRef.current = true;
    const s = usePlayerStore.getState();
    let snapshot = s,
      anchoredAt = performance.now(),
      lastActive = -2,
      raf = 0,
      visible = true;
    const render = () => {
      if (document.hidden || !visible || !synced) return;
      const time = playbackTime(
        snapshot.positionMs,
        performance.now() - anchoredAt,
        snapshot.playbackRate,
        snapshot.status === "playing",
        snapshot.durationMs,
      );
      const index = activeLineAt(lines, time);
      if (index !== lastActive) {
        lastActive = index;
        setActive(index);
        useLyricsStore.getState().setActiveLineIndex(index < 0 ? null : index);
        if (followingRef.current && index >= 0) {
          const box = container.current,
            button = buttons.current[index];
          if (box && button)
            box.scrollTo({
              top:
                button.offsetTop -
                box.clientHeight / 2 +
                button.clientHeight / 2,
              behavior: matchMedia("(prefers-reduced-motion: reduce)").matches
                ? "auto"
                : "smooth",
            });
        }
      }
      const words = lines[index]?.words;
      if (words?.length) {
        const spans =
          buttons.current[index]?.querySelectorAll<HTMLElement>("[data-word]");
        words.forEach((word, i) =>
          spans?.[i]?.style.setProperty(
            "--word-progress",
            `${wordProgress(word.timeMs, word.endMs, time).toFixed(1)}%`,
          ),
        );
      }
      if (snapshot.status === "playing") raf = requestAnimationFrame(render);
    };
    const restart = () => {
      cancelAnimationFrame(raf);
      render();
    };
    const unsubscribe = usePlayerStore.subscribe((next, previous) => {
      if (
        next.positionMs !== previous.positionMs ||
        next.status !== previous.status ||
        next.playbackRate !== previous.playbackRate ||
        next.currentTrack?.id !== previous.currentTrack?.id
      ) {
        snapshot = next;
        anchoredAt = performance.now();
        restart();
      }
    });
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      restart();
    });
    if (container.current) observer.observe(container.current);
    document.addEventListener("visibilitychange", restart);
    restart();
    return () => {
      cancelAnimationFrame(raf);
      unsubscribe();
      observer.disconnect();
      document.removeEventListener("visibilitychange", restart);
    };
  }, [lines, trackId, synced]);

  const browse = () => {
    followingRef.current = false;
    setFollowing(false);
  };
  const follow = () => {
    followingRef.current = true;
    setFollowing(true);
    const box = container.current,
      button = buttons.current[active];
    if (box && button)
      box.scrollTo({
        top: button.offsetTop - box.clientHeight / 2 + button.clientHeight / 2,
        behavior: "smooth",
      });
  };
  return (
    <section className="mobile-lyrics" aria-label="Tekst utworu">
      <div
        ref={container}
        className="mobile-lyrics-scroll"
        onTouchMove={browse}
        onWheel={browse}
        onKeyDown={(e) => {
          if (["ArrowDown", "ArrowUp", "PageDown", "PageUp"].includes(e.key))
            browse();
        }}
        tabIndex={0}
      >
        {lines.map((line, i) => (
          <button
            type="button"
            key={`${trackId}:${i}`}
            ref={(el) => {
              buttons.current[i] = el;
            }}
            className="mobile-lyric-line"
            data-active={synced && i === active}
            data-past={synced && i < active}
            disabled={!synced}
            aria-current={synced && i === active ? "true" : undefined}
            onClick={() => {
              playerEngine.seek(line.timeMs, true);
              follow();
            }}
          >
            {synced && line.words?.length
              ? line.words.map((word, n) => (
                  <span data-word key={n}>
                    {word.text}
                  </span>
                ))
              : line.text}
          </button>
        ))}
      </div>
      {synced && !following && (
        <button className="mobile-lyrics-follow" onClick={follow}>
          Wróć do aktualnej linijki
        </button>
      )}
    </section>
  );
});
