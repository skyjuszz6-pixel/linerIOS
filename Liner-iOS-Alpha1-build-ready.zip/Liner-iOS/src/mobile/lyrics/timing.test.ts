import { describe, expect, it } from "vitest";
import { activeLineAt, playbackTime, wordProgress } from "./timing";
describe("native lyric timing", () => {
  it("holds position while paused or buffering", () =>
    expect(playbackTime(1200, 9000, 1, false, 20000)).toBe(1200));
  it("uses playback speed and clamps at duration", () => {
    expect(playbackTime(1200, 100, 2, true, 20000)).toBe(1400);
    expect(playbackTime(1200, 10000, 2, true, 2000)).toBe(2000);
  });
  it("selects exact lines before, during and after seeks", () => {
    const lines = [{ timeMs: 1000 }, { timeMs: 2000 }, { timeMs: 4000 }];
    expect(activeLineAt(lines, 900)).toBe(-1);
    expect(activeLineAt(lines, 2000)).toBe(1);
    expect(activeLineAt(lines, 5000)).toBe(2);
    expect(activeLineAt(lines, 1500)).toBe(0);
    expect(activeLineAt([], 100)).toBe(-1);
  });
  it("calculates only supplied word intervals, including zero duration", () => {
    expect(wordProgress(1000, 2000, 1500)).toBe(50);
    expect(wordProgress(1000, 2000, 500)).toBe(0);
    expect(wordProgress(1000, 2000, 2500)).toBe(100);
    expect(wordProgress(1000, 1000, 1000)).toBe(100);
  });
});
