import { describe, it, expect } from "vitest";
import { mobileHeaders } from "./transport";
describe("mobile provider headers", () => {
  it("maps the desktop UA header for YouTube", () => {
    const h = mobileHeaders(
      "https://www.youtube.com/youtubei/v1/player",
      new Headers({
        "x-liner-user-agent": "test-agent",
        Authorization: "Bearer test",
      }),
    );
    expect(h["User-Agent"]).toBe("test-agent");
    expect(h["x-liner-user-agent"]).toBeUndefined();
    expect(h.authorization).toBe("Bearer test");
  });
  it("does not rewrite unrelated hosts", () => {
    expect(
      mobileHeaders(
        "https://example.org",
        new Headers({ "x-liner-user-agent": "x" }),
      )["User-Agent"],
    ).toBeUndefined();
  });
  it("does not trust a provider-name suffix spoof", () => {
    expect(
      mobileHeaders(
        "https://notyoutube.com",
        new Headers({ "x-liner-user-agent": "x" }),
      )["User-Agent"],
    ).toBeUndefined();
  });
});
