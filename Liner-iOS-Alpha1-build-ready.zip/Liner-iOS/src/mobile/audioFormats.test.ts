import { describe, expect, it } from "vitest";
import { audioCacheExtension, isIOSAudioFormat } from "./audioFormats";

describe("iOS playback formats", () => {
  it.each([
    "audio/mp4; codecs=mp4a.40.2",
    "audio/mpeg",
    "audio/flac",
    "audio/x-wav",
    "application/vnd.apple.mpegurl",
  ])("accepts supported container %s", (mime) => {
    expect(isIOSAudioFormat(mime)).toBe(true);
  });
  it.each([
    "audio/webm; codecs=opus",
    "audio/ogg",
    "",
    "text/html",
    "audio/mp4evil",
  ])("rejects unsupported or unknown container %s", (mime) => {
    expect(isIOSAudioFormat(mime)).toBe(false);
  });
  it("preserves native cache extensions instead of renaming every blob to audio", () => {
    expect(audioCacheExtension("audio/mp4")).toBe("m4a");
    expect(audioCacheExtension("audio/mpeg")).toBe("mp3");
    expect(audioCacheExtension("audio/flac")).toBe("flac");
    expect(audioCacheExtension("audio/wav")).toBe("wav");
    expect(audioCacheExtension("application/vnd.apple.mpegurl")).toBe("m3u8");
  });
});
