export function isIOSAudioFormat(mime: string): boolean {
  return /^(audio\/(mp4|mpeg|aac|x-m4a|wav|x-wav|flac|x-flac)|application\/(vnd\.apple\.mpegurl|x-mpegurl))(;|$)/i.test(
    mime,
  );
}
export function audioCacheExtension(mime: string): string {
  if (/mp4|m4a/i.test(mime)) return "m4a";
  if (/mpegurl/i.test(mime)) return "m3u8";
  if (/mpeg/i.test(mime)) return "mp3";
  if (/flac/i.test(mime)) return "flac";
  if (/wav/i.test(mime)) return "wav";
  if (/aac/i.test(mime)) return "aac";
  return "audio";
}
