import MobileMarquee from "./MobileMarquee";
import { usePlayerState } from "@/features/player/hooks/usePlayerState";
import { playerEngine } from "@/features/player/engine/playerEngine";
import { usePlayerStore } from "@/features/player/store/playerStore";

export default function MobilePlayer({
  onQueueToggle,
}: {
  onQueueToggle: () => void;
}) {
  const state = usePlayerState();
  const track = state.currentTrack;
  if (!track) return null;
  return (
    <section className="mobile-player" aria-label="Odtwarzacz">
      <button
        className="mobile-track"
        onClick={() => usePlayerStore.getState().setFullscreen(true)}
      >
        {track.coverUrl && <img src={track.coverUrl} alt="" />}
        <span>
          <strong>
            <MobileMarquee label={track.title}>{track.title}</MobileMarquee>
          </strong>
          <small>
            <MobileMarquee label={track.artists}>{track.artists}</MobileMarquee>
          </small>
        </span>
      </button>
      <button
        aria-label="Poprzedni utwór"
        onClick={() => void playerEngine.skipPrevious()}
      >
        ⏮
      </button>
      <button
        aria-label={
          state.status === "playing" || state.status === "loading"
            ? "Pauza"
            : "Odtwórz"
        }
        onClick={() => {
          playerEngine.primeUserGesture();
          playerEngine.togglePlayPause();
        }}
      >
        {state.status === "loading"
          ? "…"
          : state.status === "playing"
            ? "⏸"
            : "▶"}
      </button>
      <button
        aria-label="Następny utwór"
        onClick={() => void playerEngine.skipNext()}
      >
        ⏭
      </button>
      <input
        aria-label="Pozycja utworu"
        type="range"
        min="0"
        max={Math.max(state.durationMs, 1)}
        value={Math.min(state.positionMs, Math.max(state.durationMs, 1))}
        onChange={(e) => playerEngine.seek(Number(e.target.value))}
      />
      <details className="mobile-player-options">
        <summary>Głośność i kolejka</summary>
        <label>
          Głośność
          <input
            aria-label="Głośność"
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={state.volume}
            onChange={(e) =>
              usePlayerStore.getState().setVolume(Number(e.target.value))
            }
          />
        </label>
        <button onClick={onQueueToggle}>Otwórz kolejkę</button>
      </details>
      {state.error && (
        <small role="alert" className="mobile-error">
          {state.error}
        </small>
      )}
    </section>
  );
}
