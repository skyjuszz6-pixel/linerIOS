import { beforeEach, describe, it, expect, vi } from "vitest";
const m = vi.hoisted(() => {
  const listeners: Record<string, (s: any) => void> = {};
  const state = { items: [] as any[], index: 0, revision: "" };
  const snapshot = () => ({
    key: state.items[state.index]?.key ?? "",
    revision: state.revision,
    status: "playing",
    positionMs: 0,
    durationMs: 1000,
  });
  const transition = () => {
    listeners.transition?.({ ...snapshot(), reason: 1 });
    listeners.state?.(snapshot());
  };
  return {
    listeners,
    platform: "android",
    state,
    snapshot,
    transition,
    resolve: vi.fn(),
    getAudio: vi.fn(async () => null),
    audio: {
      addListener: vi.fn(async (n: string, c: any) => {
        listeners[n] = c;
      }),
      getState: vi.fn(async () => ({ key: "", revision: "" })),
      setQueue: vi.fn(async (o: any) => {
        state.items = o.items;
        state.revision = o.revision;
        state.index = Math.max(
          0,
          o.items.findIndex((t: any) => t.key === o.selectedKey),
        );
        return snapshot();
      }),
      select: vi.fn(async (o: any) => {
        state.index = state.items.findIndex((t) => t.key === o.key);
        transition();
        return snapshot();
      }),
      supplySource: vi.fn(async () => {}),
      failSource: vi.fn(async () => {}),
      configure: vi.fn(async () => snapshot()),
      pause: vi.fn(async () => ({ ...snapshot(), status: "paused" })),
      play: vi.fn(async () => snapshot()),
      stop: vi.fn(async () => ({ key: "", revision: "" })),
      seek: vi.fn(async (o: any) => ({
        ...snapshot(),
        positionMs: o.positionMs,
      })),
      next: vi.fn(async () => {
        state.index = Math.min(state.index + 1, state.items.length - 1);
        transition();
        return snapshot();
      }),
      previous: vi.fn(async () => {
        state.index = Math.max(0, state.index - 1);
        transition();
        return snapshot();
      }),
      cacheAudio: vi.fn(),
    },
  };
});
vi.mock("@capacitor/core", () => ({
  Capacitor: { getPlatform: () => m.platform },
  registerPlugin: () => m.audio,
}));
vi.mock("@/features/player/engine/streamResolver", () => ({
  resolvePlaybackStream: m.resolve,
}));
vi.mock("@/shared/storage", () => ({ linerDb: { getAudio: m.getAudio } }));
const tracks = (count: number, local = false) =>
  Array.from({ length: count }, (_, i) => ({
    id: `t${i}`,
    title: `Track ${i}`,
    artists: "Test",
    coverUrl: "",
    durationMs: 1000,
    playCount: 0,
    ...(local ? { localUrl: `file:///app/files/offline/${i}.mp3` } : {}),
  }));
beforeEach(() => {
  vi.resetModules();
  vi.clearAllMocks();
  m.platform = "android";
  m.state.items = [];
  m.state.index = 0;
  m.resolve.mockReset();
  m.resolve.mockResolvedValue({
    url: "https://example.org/audio.mp3",
    expiresAtMs: null,
  });
});
async function setup(count: number, local = false) {
  const { usePlayerStore } =
    await import("@/features/player/store/playerStore");
  const q = tracks(count, local);
  usePlayerStore.getState().setQueue(q);
  usePlayerStore.getState().setCurrentTrack(q[0], 0);
  usePlayerStore.getState().setAutoplaySimilar(false);
  const { NativeAudioRuntime } = await import("./nativeAudio");
  const runtime = new NativeAudioRuntime();
  await runtime.loadAndPlay(q[0]);
  return { runtime, q, store: usePlayerStore };
}
describe("native queue adapter (bridge simulation, not device playback)", () => {
  it("sends a complete ordered playlist to one native player", async () => {
    await setup(20);
    expect(m.audio.setQueue).toHaveBeenCalledTimes(1);
    expect(m.state.items).toHaveLength(20);
    expect(m.state.items[19].key).toBe("19:t19");
    await vi.waitFor(() =>
      expect(m.audio.supplySource).toHaveBeenCalledTimes(20),
    );
  });
  it("adopts 20 successive native transitions without double skips", async () => {
    const { runtime, store } = await setup(20, true);
    runtime.onEnded = vi.fn();
    for (let i = 0; i < 20; i++) {
      m.state.index = i;
      m.transition();
      expect(store.getState().currentIndex).toBe(i);
      expect(store.getState().currentTrack?.id).toBe("t" + i);
    }
    expect(m.audio.next).not.toHaveBeenCalled();
    expect(m.audio.select).not.toHaveBeenCalled();
    expect(m.resolve).not.toHaveBeenCalled();
  });
  it("serializes 30 rapid skip commands and ends on the correct track", async () => {
    const { runtime, store } = await setup(31, true);
    await Promise.all(
      Array.from({ length: 30 }, () => runtime.skipNative("next")),
    );
    expect(m.audio.next).toHaveBeenCalledTimes(30);
    expect(store.getState().currentIndex).toBe(30);
    expect(m.audio.setQueue).toHaveBeenCalledTimes(1);
  });
  it("ignores stale states from a replaced queue", async () => {
    const { runtime, store } = await setup(3, true);
    const stale = m.snapshot();
    const q = tracks(4, true);
    store.getState().setQueue(q);
    store.getState().setCurrentTrack(q[2], 2);
    await runtime.loadAndPlay(q[2]);
    m.listeners.state(stale);
    expect(store.getState().currentIndex).toBe(2);
  });
  it("propagates repeat and seek without reloading the playlist", async () => {
    const { runtime, store } = await setup(3, true);
    store.getState().setRepeat("one");
    await vi.waitFor(() =>
      expect(m.audio.configure).toHaveBeenLastCalledWith(
        expect.objectContaining({ repeat: "one" }),
      ),
    );
    runtime.seek(456);
    await vi.waitFor(() => expect(store.getState().positionMs).toBe(456));
    expect(m.audio.setQueue).toHaveBeenCalledTimes(1);
  });
  it("reports source failure to native instead of fabricating playback", async () => {
    m.resolve.mockRejectedValue(new Error("HTTP 403"));
    const { runtime } = await setup(1);
    runtime.onError = vi.fn();
    await vi.waitFor(() =>
      expect(m.audio.failSource).toHaveBeenCalledWith({
        key: "0:t0",
        revision: m.state.revision,
      }),
    );
    expect(m.audio.supplySource).not.toHaveBeenCalled();
  });
  it("prioritizes the selected song over two slow preloads after a skip", async () => {
    m.resolve.mockImplementation(
      (track: { id: string }, signal: AbortSignal) => {
        if (track.id !== "t0" && track.id !== "t1")
          return Promise.resolve({
            url: "https://example.org/" + track.id + ".mp3",
          });
        return new Promise((_, reject) => {
          signal.addEventListener(
            "abort",
            () => reject(new DOMException("Aborted", "AbortError")),
            { once: true },
          );
        });
      },
    );
    const { runtime, store, q } = await setup(31);
    await vi.waitFor(() => expect(m.resolve).toHaveBeenCalledTimes(2));
    store.getState().setCurrentTrack(q[30], 30);
    await runtime.loadAndPlay(q[30]);
    await vi.waitFor(() =>
      expect(m.audio.supplySource).toHaveBeenCalledWith(
        expect.objectContaining({ key: "30:t30", revision: m.state.revision }),
      ),
    );
    expect(m.resolve.mock.calls[2][0].id).toBe("t30");
    runtime.stop();
  });
  it("ignores source requests belonging to a replaced queue", async () => {
    await setup(3, true);
    await vi.waitFor(() =>
      expect(m.audio.supplySource).toHaveBeenCalledTimes(3),
    );
    const count = m.audio.supplySource.mock.calls.length;
    m.listeners.sourceNeeded({ key: "0:t0", revision: "old-queue" });
    await new Promise((resolve) => setTimeout(resolve, 10));
    expect(m.audio.supplySource).toHaveBeenCalledTimes(count);
  });
  it("reports another natural end after replaying the same last track", async () => {
    const { runtime } = await setup(1, true);
    runtime.onEnded = vi.fn();
    const end = { ...m.snapshot(), ended: true, status: "paused" };
    m.listeners.ended(end);
    m.listeners.ended(end);
    expect(runtime.onEnded).toHaveBeenCalledTimes(1);
    m.listeners.state({ ...m.snapshot(), ended: false });
    m.listeners.ended(end);
    expect(runtime.onEnded).toHaveBeenCalledTimes(2);
  });
});

describe("iOS source handling", () => {
  it("passes AAC URLs to the native player", async () => {
    m.platform = "ios";
    m.resolve.mockResolvedValue({
      url: "https://example.org/audio.m4a",
      mimeType: "audio/mp4",
      expiresAtMs: null,
    });
    await setup(1);
    await vi.waitFor(() =>
      expect(m.audio.supplySource).toHaveBeenCalledWith(
        expect.objectContaining({ url: "https://example.org/audio.m4a" }),
      ),
    );
  });
  it("reports unsupported WebM without sending it to AVPlayer", async () => {
    m.platform = "ios";
    m.resolve.mockResolvedValue({
      url: "https://example.org/audio.webm",
      mimeType: "audio/webm",
      expiresAtMs: null,
    });
    const { store } = await setup(1);
    await vi.waitFor(() => expect(m.audio.failSource).toHaveBeenCalled());
    expect(m.audio.supplySource).not.toHaveBeenCalled();
    expect(store.getState().status).toBe("error");
  });
});
