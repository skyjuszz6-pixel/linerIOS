import { useEffect, useState } from "react";
import { Capacitor, registerPlugin } from "@capacitor/core";
import type { Track } from "@/shared/types";
import { playerEngine } from "@/features/player/engine/playerEngine";
import { usePlayerStore } from "@/features/player/store/playerStore";
export const offlineAudio = registerPlugin<{
  list(): Promise<{ tracks: Track[]; bytes: number }>;
  importAudio(): Promise<{ tracks?: Track[]; bytes?: number; failed?: number }>;
  remove(o: { id: string }): Promise<{ tracks: Track[]; bytes: number }>;
}>("OfflineAudio");
export default function OfflineLibrary() {
  const [tracks, setTracks] = useState<Track[]>([]),
    [bytes, setBytes] = useState(0),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  const update = (r: { tracks?: Track[]; bytes?: number }) => {
    if (r.tracks) setTracks(r.tracks);
    if (r.bytes !== undefined) setBytes(r.bytes);
  };
  useEffect(() => {
    if (Capacitor.isNativePlatform())
      void offlineAudio
        .list()
        .then(update)
        .catch(() => setMessage("Nie udało się wczytać biblioteki."));
  }, []);
  const importFiles = async () => {
    setBusy(true);
    setMessage("");
    try {
      const r = await offlineAudio.importAudio();
      update(r);
      if (r.failed)
        setMessage(
          `Nie udało się zaimportować ${r.failed} plików. Sprawdź format i wolne miejsce.`,
        );
    } catch {
      setMessage("Import nie powiódł się. Sprawdź format i wolne miejsce.");
    } finally {
      setBusy(false);
    }
  };
  return (
    <section className="mobile-offline">
      <h3>Muzyka offline</h3>
      <p>
        {tracks.length} utworów · {(bytes / 1048576).toFixed(1)} MB
      </p>
      <button
        disabled={busy || !Capacitor.isNativePlatform()}
        onClick={() => void importFiles()}
      >
        {busy ? "Importowanie…" : "Importuj MP3 / FLAC / audio"}
      </button>
      <p>
        Pliki są kopiowane do pamięci Linera i działają bez internetu. Możesz
        też zaimportować muzykę pobraną legalnie od dostawcy.
      </p>
      {message && <p role="status">{message}</p>}
      <div className="mobile-offline-list">
        {tracks.map((track, index) => (
          <div key={track.id}>
            <button
              onClick={() =>
                void playerEngine.playTrack(
                  track,
                  tracks,
                  "Offline",
                  undefined,
                  index,
                )
              }
            >
              <strong>{track.title}</strong>
              <small>{track.artists}</small>
            </button>
            <button
              aria-label={`Usuń ${track.title}`}
              disabled={busy}
              onClick={async () => {
                if (!confirm(`Usunąć lokalną kopię „${track.title}”?`)) return;
                setBusy(true);
                try {
                  const state = usePlayerStore.getState();
                  if (state.queue.some((t) => t.id === track.id)) {
                    if (state.currentTrack?.id === track.id)
                      await playerEngine.stopAndClear();
                    else
                      state.setQueue(
                        state.queue.filter((t) => t.id !== track.id),
                      );
                  }
                  update(await offlineAudio.remove({ id: track.id }));
                } catch {
                  setMessage("Nie udało się usunąć pliku.");
                } finally {
                  setBusy(false);
                }
              }}
            >
              Usuń
            </button>
          </div>
        ))}
      </div>
      {!tracks.length && (
        <p>Brak plików offline. Dodaj własne nagrania lub pobrane utwory.</p>
      )}
    </section>
  );
}
