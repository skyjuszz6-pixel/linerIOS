import { Capacitor, CapacitorHttp } from "@capacitor/core";
export function mobileHeaders(url: string, headers: Headers) {
  const out = Object.fromEntries(headers.entries()),
    host = new URL(url).hostname;
  if (
    !["youtube.com", "music.apple.com"].some(
      (domain) => host === domain || host.endsWith("." + domain),
    )
  )
    return out;
  const ua = headers.get("x-liner-user-agent");
  if (ua) {
    out["User-Agent"] = ua;
    delete out["x-liner-user-agent"];
    out.Origin = host.endsWith("youtube.com")
      ? "https://www.youtube.com"
      : "https://music.apple.com";
    out.Referer = out.Origin + "/";
  }
  return out;
}
export function installMobileTransport() {
  if (!Capacitor.isNativePlatform()) return;
  const fetchOriginal = window.fetch.bind(window);
  window.fetch = async (input, init) => {
    const request = new Request(input, init);
    if (!request.headers.has("x-liner-user-agent"))
      return fetchOriginal(input, init);
    if (request.signal.aborted) throw new DOMException("Aborted", "AbortError");
    const promise = CapacitorHttp.request({
      url: request.url,
      method: request.method,
      headers: mobileHeaders(request.url, request.headers),
      data: ["GET", "HEAD"].includes(request.method)
        ? undefined
        : await request.text(),
      responseType: "text",
      connectTimeout: 15000,
      readTimeout: 30000,
    });
    const response = await new Promise<Awaited<typeof promise>>(
      (resolve, reject) => {
        const abort = () => reject(new DOMException("Aborted", "AbortError"));
        request.signal.addEventListener("abort", abort, { once: true });
        promise
          .then(resolve, reject)
          .finally(() => request.signal.removeEventListener("abort", abort));
      },
    );
    return new Response(
      response.status === 204
        ? null
        : typeof response.data === "string"
          ? response.data
          : JSON.stringify(response.data),
      { status: response.status, headers: response.headers },
    );
  };
}
