// @vitest-environment node
import { afterEach, describe, expect, it, vi } from "vitest";
import crypto from "node:crypto";
import * as desktop from "../../electron/crypto";
import * as mobile from "./signer";

afterEach(() => {
  vi.restoreAllMocks();
  mobile.setServerTimeOffset(0);
});
describe("Android signer protocol compatibility", () => {
  it("matches the desktop signer for authenticated requests, including Unicode bodies", () => {
    const nonce = new Uint8Array([0, 1, 2, 3, 128, 129, 254, 255]);
    vi.spyOn(crypto, "randomBytes").mockReturnValue(
      Buffer.from(nonce) as never,
    );
    vi.spyOn(globalThis.crypto, "getRandomValues").mockImplementation(
      (array: any) => {
        array.set(nonce);
        return array;
      },
    );
    for (const input of [
      { method: "GET", path: "/v1/test", timestamp: 1700000000 },
      {
        method: "POST",
        path: "/v1/auth/refresh",
        body: '{"text":"Zażółć 🎵"}',
        timestamp: 1700000001,
      },
    ]) {
      expect(mobile.signRequest(input)).toEqual(desktop.signRequest(input));
      expect(mobile.signMonitorRequest(input)).toEqual(
        desktop.signMonitorRequest(input),
      );
    }
  });
  it("preserves raw binary payload and cover signatures", () => {
    const bytes = new Uint8Array([0, 255, 128, 10, 13]);
    expect(mobile.signRawPayload(bytes)).toEqual(desktop.signRawPayload(bytes));
    expect(mobile.signCoverUrl("cover/żółć.png")).toEqual(
      desktop.signCoverUrl("cover/żółć.png"),
    );
  });
  it("adjusts the clock and ignores invalid server timestamps", () => {
    vi.spyOn(Date, "now").mockReturnValue(1700000000000);
    expect(mobile.syncServerTime(1700000005000)).toBe(5000);
    expect(mobile.getAdjustedTimestamp()).toBe(1700000005);
    expect(mobile.syncServerTime("bad date")).toBe(5000);
  });
});
