import { useEffect, useRef, useState } from "react";
import { Capacitor, registerPlugin } from "@capacitor/core";
import { usePlayerStore } from "@/features/player/store/playerStore";
import { shareActivity } from "./activity";
type Options = {
  enabled: boolean;
  title: boolean;
  artist: boolean;
  artwork: boolean;
  time: boolean;
  reconnect: boolean;
};
type State = Options & { status: string; detail: string };
const rpc = registerPlugin<{
  getState(): Promise<State>;
  configure(o: Partial<Options>): Promise<State>;
  test(): Promise<State>;
}>("DiscordPresence");
const labels: Record<string, string> = {
  disabled: "Wyłączono",
  idle: "Oczekiwanie na odtwarzanie",
  connecting: "Łączenie…",
  connected: "Połączono — publikacja potwierdzona przez SDK",
  disconnected: "Rozłączono",
  error: "Błąd",
};
export default function MobileDiscord() {
  const track = usePlayerStore((s) => s.currentTrack);
  const [state, setState] = useState<State | null>(null),
    [error, setError] = useState(""),
    [busy, setBusy] = useState(false);
  const native = Capacitor.getPlatform() === "android";
  const mutation = useRef(0);
  const [copied, setCopied] = useState(false);
  useEffect(() => {
    if (!native) return;
    let live = true;
    const refresh = () => {
      const version = mutation.current;
      if (!document.hidden)
        void rpc
          .getState()
          .then((s) => {
            if (live && version === mutation.current) {
              setState(s);
              setError("");
            }
          })
          .catch(() => {
            if (live) setError("Nie udało się odczytać stanu integracji.");
          });
    };
    refresh();
    const timer = setInterval(refresh, 2000);
    document.addEventListener("visibilitychange", refresh);
    return () => {
      live = false;
      clearInterval(timer);
      document.removeEventListener("visibilitychange", refresh);
    };
  }, [native]);
  const change = async (key: keyof Options, value: boolean) => {
    mutation.current++;
    setBusy(true);
    setError("");
    try {
      setState(await rpc.configure({ [key]: value }));
    } catch {
      setError("Nie udało się zapisać ustawienia.");
    } finally {
      mutation.current++;
      setBusy(false);
    }
  };
  if (Capacitor.getPlatform() === "ios")
    return (
      <section className="mobile-offline">
        <h3>Udostępnianie muzyki</h3>
        <p>
          Automatyczna aktywność Discord nie jest dostępna w tej wersji iOS.
        </p>
        <button
          disabled={!track}
          onClick={() =>
            track &&
            void shareActivity(track.title, track.artists).catch(() =>
              setError("Nie udało się udostępnić utworu."),
            )
          }
        >
          Udostępnij utwór
        </button>
        {error && <p role="alert">{error}</p>}
      </section>
    );
  return (
    <section className="mobile-offline">
      <h3>Discord Integration</h3>
      <p>
        Opcjonalnie publikuj słuchaną muzykę na swoim profilu Discord. Wymaga
        zainstalowanego i zalogowanego Discorda oraz włączonego udostępniania
        aktywności w Discordzie.
      </p>
      <p role="status">
        {native
          ? labels[state?.status ?? "connecting"]
          : "Dostępne w aplikacji Android"}
      </p>
      {state?.detail && <p>{state.detail}</p>}
      {(
        [
          ["enabled", "Pokazuj aktywność na Discordzie"],
          ["title", "Pokazuj tytuł utworu"],
          ["artist", "Pokazuj wykonawcę"],
          ["artwork", "Pokazuj okładkę"],
          ["time", "Pokazuj czas odtwarzania"],
          ["reconnect", "Automatycznie ponawiaj połączenie"],
        ] as const
      ).map(([key, label]) => (
        <label key={key} className="mobile-discord-option">
          <span>{label}</span>
          <input
            type="checkbox"
            checked={state?.[key] ?? false}
            disabled={!state || busy || (!state.enabled && key !== "enabled")}
            onChange={(e) => void change(key, e.target.checked)}
          />
        </label>
      ))}
      <p>
        Pauza usuwa aktywność. Czas jest pokazywany przy tempie 1×. Po kilku
        nieudanych próbach ponawianie zatrzymuje się. Odzyskanie internetu lub
        zmiana utworu uruchamia nową próbę; możesz też użyć testu ręcznie.
        Potwierdzenie SDK nie zastępuje sprawdzenia widoczności profilu przez
        drugie konto.
      </p>
      <button
        disabled={!state?.enabled || busy}
        onClick={() =>
          void rpc
            .test()
            .then(setState)
            .catch(() => setError("Test integracji nie powiódł się."))
        }
      >
        Testuj aktualny utwór
      </button>
      <button
        disabled={!track}
        onClick={() =>
          track &&
          void shareActivity(track.title, track.artists).catch(() =>
            setError("Nie udało się udostępnić utworu."),
          )
        }
      >
        Udostępnij ręcznie
      </button>
      <button
        disabled={!state}
        onClick={() => {
          void navigator.clipboard
            .writeText(
              JSON.stringify(
                {
                  app: "Liner",
                  version: "1.2-rc2",
                  sdk: "1.10.19337",
                  status: state?.status,
                  detail: state?.detail,
                  enabled: state?.enabled,
                },
                null,
                2,
              ),
            )
            .then(() => setCopied(true))
            .catch(() => setError("Nie udało się skopiować diagnostyki."));
        }}
      >
        {copied ? "Diagnostyka skopiowana" : "Kopiuj diagnostykę"}
      </button>
      {error && <p role="alert">{error}</p>}
    </section>
  );
}
